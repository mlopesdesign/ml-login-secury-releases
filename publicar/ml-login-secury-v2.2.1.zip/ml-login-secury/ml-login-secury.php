<?php
/**
 * Plugin Name: ML Login Secury
 * Plugin URI: https://mlopesdesign.com.br
 * Description: Professional WordPress login security with multi-mode login protection, brute force defense, XML-RPC shield, whitelist, logs and emergency recovery.
 * Version: 2.2.1
 * Update URI: https://github.com/mlopesdesign/ml-login-secury-releases
 * Author: Mlopesdesign
 * Author URI: https://mlopesdesign.com.br
 * Text Domain: ml-login-secury
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

define('MLS_VERSION', '2.2.1');
define('MLS_OPTION_KEY', 'mls_settings');
define('MLS_LOG_TABLE', 'mls_logs');
define('MLS_LOCK_TABLE', 'mls_lockouts');
define('MLS_MANUAL_BLOCK_TABLE', 'mls_manual_blocks');

// ─── Early Request Shield bootstrap ─────────────────────────────────────────
if (!defined('MLS_REQUEST_SHIELD_BOOTSTRAPPED')) {
    define('MLS_REQUEST_SHIELD_BOOTSTRAPPED', true);

    $mls_boot_ip    = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
    $mls_boot_uri   = (string) ($_SERVER['REQUEST_URI'] ?? '');
    $mls_boot_query = (string) ($_SERVER['QUERY_STRING'] ?? '');
    $mls_boot_ua    = sanitize_text_field(substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255));
    $mls_boot_path  = strtolower((string) parse_url($mls_boot_uri, PHP_URL_PATH));
    if ($mls_boot_path === '') { $mls_boot_path = strtolower($mls_boot_uri); }

    $mls_boot_scope = 'front';
    if (strpos($mls_boot_path, 'wp-login.php') !== false) { $mls_boot_scope = 'login'; }
    elseif (strpos($mls_boot_path, 'xmlrpc.php') !== false) { $mls_boot_scope = 'xmlrpc'; }
    elseif (strpos($mls_boot_path, 'admin-ajax.php') !== false) { $mls_boot_scope = 'ajax'; }
    elseif (strpos($mls_boot_path, 'wp-cron.php') !== false) { $mls_boot_scope = 'cron'; }

    $mls_boot_defaults = [
        'request_shield_enabled' => 1,
        'request_shield_user_agent_enabled' => 1,
        'request_shield_query_enabled' => 1,
        'request_shield_bots_only' => 1,
        'request_shield_action' => 'block',
        'request_shield_route_front' => 1,
        'request_shield_route_login' => 1,
        'request_shield_route_xmlrpc' => 1,
        'request_shield_route_ajax' => 1,
        'request_shield_route_cron' => 1,
        'request_shield_ua_patterns' => ['facebookexternalhit','Facebot','meta-externalagent','meta-webindexer'],
        'request_shield_query_patterns' => ['mlgp_page_gallery_','mlgp_album_view_'],
        'request_shield_probe_enabled' => 1,
        'whitelist_ips' => [],
        'emergency_until' => '',
        'login_emergency_token' => '',
        'login_emergency_duration_minutes' => 60,
        'login_mode' => 'whitelist',
    ];

    $mls_boot_settings = $mls_boot_defaults;
    if (function_exists('get_option')) {
        $mls_boot_saved = get_option('mls_settings', null);
        if (is_array($mls_boot_saved)) {
            $mls_boot_settings = wp_parse_args($mls_boot_saved, $mls_boot_defaults);
        }
    }

    $mls_boot_enabled = !empty($mls_boot_settings['request_shield_enabled']);
    $mls_boot_whitelist = array_values(array_filter((array) ($mls_boot_settings['whitelist_ips'] ?? [])));
    $mls_boot_emergency = !empty($mls_boot_settings['emergency_until']) && strtotime((string) $mls_boot_settings['emergency_until']) > time();
    $mls_boot_scope_enabled = !empty($mls_boot_settings['request_shield_route_' . $mls_boot_scope]);
    $mls_boot_probe_enabled = !empty($mls_boot_settings['request_shield_probe_enabled']);
    $mls_boot_safe_root_php = ['/index.php','/wp-login.php','/wp-cron.php','/xmlrpc.php','/wp-comments-post.php','/wp-links-opml.php','/wp-mail.php','/wp-activate.php','/wp-signup.php'];
    $mls_boot_safe_direct_php = array_merge($mls_boot_safe_root_php, ['/wp-admin/admin-ajax.php','/wp-admin/admin-post.php','/wp-admin/async-upload.php','/wp-admin/load-scripts.php','/wp-admin/load-styles.php']);
    $mls_boot_probe_reason = '';

    if ($mls_boot_enabled && $mls_boot_scope_enabled && !$mls_boot_emergency && !in_array($mls_boot_ip, $mls_boot_whitelist, true)) {
        $mls_boot_basename = strtolower((string) basename($mls_boot_path));
        $mls_boot_is_php = $mls_boot_basename !== '' && substr($mls_boot_basename, -4) === '.php';
        $mls_boot_suspicious_names = ['fe5.php','dx.php','wp.php','k.php','goods.php','gettest.php','chosen.php','abcd.php','a5.php','8.php','7.php','222.php','2.php','1.php','xroot.php','xmini.php','wp-update.php'];
        if ($mls_boot_probe_enabled && $mls_boot_is_php) {
            $mls_boot_is_root_php = strpos(ltrim($mls_boot_path, '/'), '/') === false;
            $mls_boot_is_wp_content_php = strpos($mls_boot_path, '/wp-content/') === 0;
            if ($mls_boot_is_root_php && !in_array($mls_boot_path, $mls_boot_safe_root_php, true)) {
                $mls_boot_probe_reason = 'probe:root-php';
            } elseif (in_array($mls_boot_basename, $mls_boot_suspicious_names, true) && !in_array($mls_boot_path, $mls_boot_safe_direct_php, true)) {
                $mls_boot_probe_reason = $mls_boot_is_wp_content_php ? 'probe:wp-content-php' : 'probe:suspicious-php';
            } elseif ($mls_boot_is_wp_content_php && in_array($mls_boot_basename, ['admin.php','wp.php','wp-update.php','xroot.php','xmini.php'], true)) {
                $mls_boot_probe_reason = 'probe:wp-content-php';
            }
        }

        $mls_boot_ua_match = '';
        if (!empty($mls_boot_settings['request_shield_user_agent_enabled'])) {
            foreach ((array) ($mls_boot_settings['request_shield_ua_patterns'] ?? []) as $pattern) {
                $pattern = trim((string) $pattern);
                if ($pattern !== '' && stripos($mls_boot_ua, $pattern) !== false) { $mls_boot_ua_match = $pattern; break; }
            }
        }

        $mls_boot_query_match = '';
        if (!empty($mls_boot_settings['request_shield_query_enabled'])) {
            $mls_boot_haystack = $mls_boot_query !== '' ? $mls_boot_query : $mls_boot_uri;
            foreach ((array) ($mls_boot_settings['request_shield_query_patterns'] ?? []) as $pattern) {
                $pattern = trim((string) $pattern);
                if ($pattern !== '' && stripos($mls_boot_haystack, $pattern) !== false) { $mls_boot_query_match = $pattern; break; }
            }
        }

        $mls_boot_hit = !empty($mls_boot_settings['request_shield_bots_only'])
            ? ($mls_boot_ua_match !== '' && $mls_boot_query_match !== '')
            : ($mls_boot_ua_match !== '' || $mls_boot_query_match !== '');
        if ($mls_boot_probe_reason !== '') { $mls_boot_hit = true; }

        if ($mls_boot_hit) {
            global $wpdb;
            if (isset($wpdb) && !empty($wpdb->prefix) && !empty($mls_boot_settings['request_shield_action'])) {
                $mls_boot_event  = $mls_boot_settings['request_shield_action'] === 'log' ? 'request_shield_log' : 'request_shield_block';
                $mls_boot_status = $mls_boot_settings['request_shield_action'] === 'log' ? 'warning' : 'blocked';
                $mls_boot_route_map = ['front'=>'front-end','login'=>'wp-login.php','xmlrpc'=>'xmlrpc.php','ajax'=>'admin-ajax.php','cron'=>'wp-cron.php'];
                $mls_boot_route = $mls_boot_route_map[$mls_boot_scope] ?? 'unknown';
                $mls_boot_details = 'scope:' . $mls_boot_route;
                if ($mls_boot_probe_reason !== '') { $mls_boot_details .= ' | ' . $mls_boot_probe_reason; }
                if ($mls_boot_ua_match !== '') { $mls_boot_details .= ' | ua:' . $mls_boot_ua_match; }
                if ($mls_boot_query_match !== '') { $mls_boot_details .= ' | query:' . $mls_boot_query_match; }
                @$wpdb->insert($wpdb->prefix . 'mls_logs', [
                    'created_at' => function_exists('current_time') ? current_time('mysql') : gmdate('Y-m-d H:i:s'),
                    'ip' => substr($mls_boot_ip, 0, 45), 'username' => '',
                    'event_type' => $mls_boot_event, 'status' => $mls_boot_status,
                    'route' => substr($mls_boot_route, 0, 50), 'details' => $mls_boot_details,
                    'user_agent' => substr($mls_boot_ua, 0, 255),
                ], ['%s','%s','%s','%s','%s','%s','%s','%s']);
            }
            if (($mls_boot_settings['request_shield_action'] ?? 'block') === 'block') {
                if (!headers_sent()) {
                    header('HTTP/1.1 403 Forbidden', true, 403);
                    header('Status: 403 Forbidden', true, 403);
                    header('Content-Type: text/plain; charset=utf-8');
                    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
                    header('Pragma: no-cache');
                    header('X-MLS-Request-Shield: blocked');
                }
                echo 'Forbidden';
                exit;
            }
        }
    }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function mls_defaults() {
    return [
        'mode' => 'limit',
        'max_attempts' => 5,
        'time_window_minutes' => 15,
        'base_lock_minutes' => 15,
        'whitelist_ips' => [],
        'emergency_until' => '',
        'xmlrpc_mode' => 'limit',
        'alert_email' => '',
        'alert_threshold' => 20,
        'recurrence_lockouts' => 3,
        'request_shield_enabled' => 1,
        'request_shield_user_agent_enabled' => 1,
        'request_shield_query_enabled' => 1,
        'request_shield_bots_only' => 1,
        'request_shield_action' => 'block',
        'request_shield_route_front' => 1,
        'request_shield_route_login' => 1,
        'request_shield_route_xmlrpc' => 1,
        'request_shield_route_ajax' => 1,
        'request_shield_route_cron' => 1,
        'request_shield_ua_patterns' => ['facebookexternalhit','Facebot','meta-externalagent','meta-webindexer'],
        'request_shield_query_patterns' => ['mlgp_page_gallery_','mlgp_album_view_'],
        'request_shield_probe_enabled' => 1,
        // New in v2.0.0 — login mode settings
        'login_mode' => 'whitelist',
        'login_custom_slug' => '',
        'login_original_behavior' => '403',
        // New in v2.1.0 — throttle config for standard/custom modes
        'throttle_window'   => 300,
        'throttle_limit'    => 8,
        'throttle_lockout'  => 900,
    ];
}

function mls_settings() {
    return wp_parse_args(get_option(MLS_OPTION_KEY, []), mls_defaults());
}

function mls_ip() { return sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'); }
function mls_now() { return current_time('mysql'); }
function mls_current_user_agent() { return sanitize_text_field(substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255)); }
function mls_bool_setting($value) { return !empty($value) ? 1 : 0; }

function mls_clean_pattern_lines($raw) {
    $raw = str_replace(["\r\n", "\r"], "\n", (string) $raw);
    $clean = [];
    foreach (explode("\n", $raw) as $line) {
        $line = trim(wp_unslash($line));
        if ($line !== '') { $clean[$line] = $line; }
    }
    return array_values($clean);
}

function mls_generate_emergency_token() {
    try { return bin2hex(random_bytes(24)); }
    catch (Exception $e) { return substr(hash('sha256', wp_generate_password(64, true, true) . microtime(true) . wp_rand()), 0, 48); }
}

function mls_sanitize_login_slug($raw) {
    $slug = strtolower(trim((string) $raw));
    $slug = preg_replace('/[^a-z0-9\-\_]/', '', $slug);
    $slug = trim($slug, '-_');
    return $slug;
}

// ─── Flat file export paths ───────────────────────────────────────────────────

function mls_export_dir() {
    $dir = trailingslashit(WP_CONTENT_DIR) . 'uploads/ml-login-secury';
    if (!is_dir($dir)) { wp_mkdir_p($dir); }
    return trailingslashit($dir);
}

function mls_login_token_export_path() { return mls_export_dir() . 'whitelist-login-token.php'; }
function mls_login_whitelist_export_path() { return mls_export_dir() . 'whitelist-login.txt'; }

function mls_write_flat_php($file, $value) {
    $dir = dirname($file);
    if (!is_dir($dir)) { wp_mkdir_p($dir); }
    if (!is_writable($dir)) { return false; }
    $export = "<?php\nreturn " . var_export($value, true) . ";\n";
    return (bool) file_put_contents($file, $export, LOCK_EX);
}

function mls_write_login_token_export($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    $token = trim((string) ($settings['login_emergency_token'] ?? ''));
    if ($token === '') {
        $token = mls_generate_emergency_token();
        $settings['login_emergency_token'] = $token;
        update_option(MLS_OPTION_KEY, $settings, false);
    }
    $duration = max(5, (int) ($settings['login_emergency_duration_minutes'] ?? 60));
    return mls_write_flat_php(mls_login_token_export_path(), ['token' => $token, 'duration' => $duration]);
}

function mls_write_login_whitelist_export($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    $ips = array_values(array_unique(array_filter(array_map('trim', (array) ($settings['whitelist_ips'] ?? [])))));
    $export = implode("\n", $ips);
    if ($export !== '') { $export .= "\n"; }
    $file = mls_login_whitelist_export_path();
    $dir = dirname($file);
    if (!is_dir($dir)) { wp_mkdir_p($dir); }
    if (!is_writable($dir)) { return false; }
    return (bool) file_put_contents($file, $export, LOCK_EX);
}

function mls_write_login_mode_export($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    $mode = in_array(($settings['login_mode'] ?? 'whitelist'), ['whitelist','custom','standard'], true) ? $settings['login_mode'] : 'whitelist';
    return mls_write_flat_php(mls_export_dir() . 'login-mode.php', $mode);
}

function mls_write_custom_slug_export($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    $slug = mls_sanitize_login_slug($settings['login_custom_slug'] ?? '');
    return mls_write_flat_php(mls_export_dir() . 'custom-login-slug.php', $slug);
}

function mls_write_original_login_behavior_export($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    $behavior = in_array(($settings['login_original_behavior'] ?? '403'), ['403','404','home'], true) ? $settings['login_original_behavior'] : '403';
    return mls_write_flat_php(mls_export_dir() . 'original-login-behavior.php', $behavior);
}

function mls_write_site_home_url_export() {
    return mls_write_flat_php(mls_export_dir() . 'site-home-url.php', home_url('/'));
}

function mls_write_bypass_secret_export() {
    $file = mls_export_dir() . 'bypass-secret.php';
    // Só gerar se não existir — secret deve ser estável
    if (is_file($file) && is_readable($file)) {
        $existing = @include $file;
        if (is_string($existing) && strlen($existing) >= 32) {
            return true; // já existe e é válido
        }
    }
    try {
        $secret = bin2hex(random_bytes(32));
    } catch (Exception $e) {
        $secret = hash('sha256', wp_generate_password(64, true, true) . microtime(true) . wp_rand());
    }
    return mls_write_flat_php($file, $secret);
}

function mls_write_throttle_config_export($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    $config = [
        'window'  => max(60,  (int) ($settings['throttle_window']  ?? 300)),
        'limit'   => max(3,   (int) ($settings['throttle_limit']   ?? 8)),
        'lockout' => max(300, (int) ($settings['throttle_lockout'] ?? 900)),
    ];
    return mls_write_flat_php(mls_export_dir() . 'throttle-config.php', $config);
}

function mls_write_all_flat_exports($settings = null) {
    if ($settings === null) { $settings = mls_settings(); }
    mls_write_login_whitelist_export($settings);
    mls_write_login_token_export($settings);
    mls_write_login_mode_export($settings);
    mls_write_custom_slug_export($settings);
    mls_write_original_login_behavior_export($settings);
    mls_write_site_home_url_export();
    mls_write_bypass_secret_export();
    mls_write_throttle_config_export($settings);
}

// ─── MU loader ───────────────────────────────────────────────────────────────

define('MLS_MU_REV', '2');

function mls_mu_loader_path() {
    return trailingslashit(WP_CONTENT_DIR) . 'mu-plugins/mls-early.php';
}

function mls_mu_loader_code() {
    // Rev 2: so carrega o early-block se o arquivo existir. Evita erro fatal no site inteiro
    // durante a atualizacao (pasta do plugin trocada) ou se o plugin for removido.
    return "<?php\n// ML Login Secury - early loader (rev " . MLS_MU_REV . ")\n"
        . "\$mls_early_file = WP_PLUGIN_DIR . '/ml-login-secury/early-block.php';\n"
        . "if (is_file(\$mls_early_file)) {\n    require_once \$mls_early_file;\n}\n"
        . "unset(\$mls_early_file);\n";
}

function mls_write_mu_loader() {
    $mu_dir = trailingslashit(WP_CONTENT_DIR) . 'mu-plugins';
    if (!is_dir($mu_dir)) { wp_mkdir_p($mu_dir); }
    if (!is_dir($mu_dir) || !is_writable($mu_dir)) { return false; }
    $loader_file = mls_mu_loader_path();
    $loader_code = mls_mu_loader_code();
    if (is_file($loader_file) && (string) @file_get_contents($loader_file) === $loader_code) {
        update_option('mls_mu_rev', MLS_MU_REV, true);
        return true;
    }
    $tmp = $loader_file . '.tmp';
    if (false === @file_put_contents($tmp, $loader_code, LOCK_EX) || filesize($tmp) !== strlen($loader_code)) {
        @unlink($tmp);
        return false;
    }
    if (!@rename($tmp, $loader_file)) {
        @unlink($tmp);
        return false;
    }
    update_option('mls_mu_rev', MLS_MU_REV, true);
    return true;
}

// Atualizacoes nao passam pela ativacao: regrava o loader antigo (sem protecao) uma unica vez.
// So troca um loader que ja existe; criar do zero continua no admin_init, junto com os arquivos
// de configuracao do early-block (sem eles o early-block cairia no modo whitelist).
add_action('plugins_loaded', function () {
    if (get_option('mls_mu_rev') !== MLS_MU_REV && is_file(mls_mu_loader_path())) {
        mls_write_mu_loader();
    }
}, 1);

// Desativado: o early-block nao deve continuar ativo, e o loader nao pode apontar para um plugin removido.
register_deactivation_hook(__FILE__, function () {
    $loader = mls_mu_loader_path();
    if (is_file($loader)) { @unlink($loader); }
    delete_option('mls_mu_rev');
});

// ─── Request Shield helpers ───────────────────────────────────────────────────

function mls_request_shield_settings() {
    $s = mls_settings();
    return [
        'enabled' => !empty($s['request_shield_enabled']),
        'ua_enabled' => !empty($s['request_shield_user_agent_enabled']),
        'query_enabled' => !empty($s['request_shield_query_enabled']),
        'bots_only' => !empty($s['request_shield_bots_only']),
        'action' => in_array(($s['request_shield_action'] ?? 'block'), ['log', 'block'], true) ? $s['request_shield_action'] : 'block',
        'route_front' => !empty($s['request_shield_route_front']),
        'route_login' => !empty($s['request_shield_route_login']),
        'route_xmlrpc' => !empty($s['request_shield_route_xmlrpc']),
        'route_ajax' => !empty($s['request_shield_route_ajax']),
        'route_cron' => !empty($s['request_shield_route_cron']),
        'ua_patterns' => array_values(array_filter((array) ($s['request_shield_ua_patterns'] ?? []))),
        'query_patterns' => array_values(array_filter((array) ($s['request_shield_query_patterns'] ?? []))),
        'probe_enabled' => !empty($s['request_shield_probe_enabled']),
    ];
}

function mls_request_route_scope() {
    $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
    $path = strtolower((string) parse_url($uri, PHP_URL_PATH));
    if ($path === '') { $path = strtolower($uri); }
    if (strpos($path, 'wp-login.php') !== false) { return 'login'; }
    if (strpos($path, 'xmlrpc.php') !== false) { return 'xmlrpc'; }
    if (strpos($path, 'admin-ajax.php') !== false) { return 'ajax'; }
    if (strpos($path, 'wp-cron.php') !== false) { return 'cron'; }
    return 'front';
}

function mls_request_route_label($scope) {
    $map = ['front'=>'front-end','login'=>'wp-login.php','xmlrpc'=>'xmlrpc.php','ajax'=>'admin-ajax.php','cron'=>'wp-cron.php'];
    return $map[$scope] ?? 'unknown';
}

function mls_request_scope_enabled($cfg, $scope) {
    $key_map = ['front'=>'route_front','login'=>'route_login','xmlrpc'=>'route_xmlrpc','ajax'=>'route_ajax','cron'=>'route_cron'];
    $key = $key_map[$scope] ?? '';
    return $key && !empty($cfg[$key]);
}

function mls_find_first_match($haystack, $patterns) {
    $haystack = strtolower((string) $haystack);
    foreach ((array) $patterns as $pattern) {
        $pattern = trim((string) $pattern);
        if ($pattern !== '' && strpos($haystack, strtolower($pattern)) !== false) { return $pattern; }
    }
    return '';
}

function mls_request_shield_summary($scope, $ua_match, $query_match, $probe_reason = '') {
    $parts = ['scope:' . mls_request_route_label($scope)];
    if ($probe_reason) { $parts[] = $probe_reason; }
    if ($ua_match) { $parts[] = 'ua:' . $ua_match; }
    if ($query_match) { $parts[] = 'query:' . $query_match; }
    return implode(' | ', $parts);
}

function mls_current_request_uri() { return sanitize_text_field(substr((string) ($_SERVER['REQUEST_URI'] ?? ''), 0, 500)); }

function mls_is_whitelisted($ip) {
    $s = mls_settings();
    return in_array($ip, (array) $s['whitelist_ips'], true);
}

function mls_clean_ip_list($raw) {
    $raw = str_replace(["\r\n", "\r"], "\n", (string) $raw);
    $clean = [];
    foreach (explode("\n", $raw) as $line) {
        $ip = trim(wp_unslash($line));
        if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP)) { $clean[$ip] = $ip; }
    }
    return array_values($clean);
}

function mls_logo_url() { return esc_url(plugin_dir_url(__FILE__) . 'assets/images/logo-wordpress.png'); }

function mls_emergency_active() {
    $s = mls_settings();
    return !empty($s['emergency_until']) && strtotime($s['emergency_until']) > time();
}

function mls_emergency_remaining() {
    $s = mls_settings();
    if (empty($s['emergency_until'])) { return 0; }
    return max(0, strtotime($s['emergency_until']) - time());
}

function mls_seconds_remaining_from_datetime($datetime) {
    if (!$datetime) { return 0; }
    return max(0, strtotime($datetime) - current_time('timestamp'));
}

function mls_format_seconds_remaining($seconds) {
    if ($seconds <= 0) { return 'expirado'; }
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    $secs = $seconds % 60;
    if ($hours > 0) { return sprintf('%dh %02dm %02ds', $hours, $minutes, $secs); }
    return sprintf('%dm %02ds', $minutes, $secs);
}

function mls_is_manually_blocked($ip) {
    global $wpdb;
    return (bool) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}" . MLS_MANUAL_BLOCK_TABLE . " WHERE ip=%s LIMIT 1", $ip));
}

function mls_guess_ip_type($ip) {
    if (strpos($ip, ':') !== false) { return 'IPv6'; }
    if (preg_match('/^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/', $ip)) { return 'Privado'; }
    return 'IPv4';
}

function mls_guess_source($ip) {
    if ($ip === '127.0.0.1' || $ip === '::1') { return 'Localhost'; }
    if (preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/', $ip)) { return 'Rede privada'; }
    return 'Externo';
}

function mls_get_ip_event_counts($ip) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare("SELECT event_type, COUNT(*) as total FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE ip=%s GROUP BY event_type", $ip));
    $counts = ['login_failure'=>0,'lockout_created'=>0,'xmlrpc_request'=>0,'xmlrpc_blocked'=>0,'auto_manual_block'=>0,'request_shield_log'=>0,'request_shield_block'=>0];
    foreach ((array) $rows as $row) { $counts[$row->event_type] = (int) $row->total; }
    return $counts;
}

function mls_calculate_risk_score($ip) {
    $c = mls_get_ip_event_counts($ip);
    $score = ($c['login_failure']*2)+($c['lockout_created']*15)+($c['xmlrpc_request']*1)+($c['xmlrpc_blocked']*6)+($c['auto_manual_block']*20)+($c['request_shield_log']*1)+($c['request_shield_block']*4);
    if (mls_is_manually_blocked($ip)) { $score += 50; }
    return $score;
}

function mls_risk_label($score) {
    if ($score >= 80) return 'Crítico';
    if ($score >= 40) return 'Alto';
    if ($score >= 15) return 'Médio';
    return 'Baixo';
}

function mls_row_action_buttons_from_ip($ip, $context = 'logs') {
    $url_base = admin_url('admin.php?page=mls-dashboard');
    $tab = $context === 'logs' ? 'logs' : 'lockouts';
    $out = '';
    if (!mls_is_whitelisted($ip)) {
        $out .= '<a class="mls-action-button mls-action-button--secondary" href="' . esc_url(add_query_arg(['tab' => $tab, 'mls_quick_whitelist_ip' => $ip], $url_base)) . '">Whitelist</a> ';
    }
    if (!mls_is_manually_blocked($ip)) {
        $out .= '<a class="mls-action-button mls-action-button--secondary" href="' . esc_url(add_query_arg(['tab' => $tab, 'mls_quick_block_ip' => $ip], $url_base)) . '">Bloquear</a>';
    }
    return trim($out);
}

function mls_recurrence_should_block($ip) {
    global $wpdb;
    $s = mls_settings();
    $count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE ip=%s AND event_type='lockout_created'", $ip));
    return $count >= max(1, (int) $s['recurrence_lockouts']);
}

function mls_maybe_send_alert_email($event_type) {
    if (!in_array($event_type, ['login_failure','xmlrpc_request','xmlrpc_blocked','lockout_created','request_shield_log','request_shield_block'], true)) { return; }
    $s = mls_settings();
    $email = sanitize_email($s['alert_email'] ?? '');
    $threshold = max(1, (int) ($s['alert_threshold'] ?? 20));
    if (!$email || !is_email($email)) { return; }
    if (get_transient('mls_alert_cooldown')) { return; }
    global $wpdb;
    $window_start = date('Y-m-d H:i:s', time() - 900);
    $count = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE created_at >= %s AND status IN ('failed','blocked','warning')", $window_start));
    if ($count < $threshold) { return; }
    $subject = '[ML Login Secury] Pico de ataque detectado';
    $body = "Site: " . home_url() . "\nEventos nos últimos 15 minutos: " . $count . "\nThreshold: " . $threshold . "\nIP: " . mls_ip() . "\nEvento: " . $event_type;
    wp_mail($email, $subject, $body);
    set_transient('mls_alert_cooldown', 1, HOUR_IN_SECONDS);
}

// ─── Request Shield runtime ───────────────────────────────────────────────────

function mls_request_shield_early_intercept() {
    if (is_admin()) { return; }
    $cfg = mls_request_shield_settings();
    if (empty($cfg['enabled'])) { return; }
    $ip = mls_ip();
    if (mls_is_whitelisted($ip) || mls_emergency_active() || mls_is_manually_blocked($ip)) { return; }
    $scope = mls_request_route_scope();
    if (!mls_request_scope_enabled($cfg, $scope)) { return; }
    $ua = mls_current_user_agent();
    $uri = mls_current_request_uri();
    $path = strtolower((string) parse_url($uri, PHP_URL_PATH));
    if ($path === '') { $path = strtolower($uri); }
    $ua_match = !empty($cfg['ua_enabled']) ? mls_find_first_match($ua, $cfg['ua_patterns']) : '';
    $query_match = !empty($cfg['query_enabled']) ? mls_find_first_match($uri, $cfg['query_patterns']) : '';
    $probe_reason = '';
    if (!empty($cfg['probe_enabled'])) {
        $basename = strtolower((string) basename($path));
        $is_php = $basename !== '' && substr($basename, -4) === '.php';
        if ($is_php) {
            $safe_root_php = ['/index.php','/wp-login.php','/wp-cron.php','/xmlrpc.php','/wp-comments-post.php','/wp-links-opml.php','/wp-mail.php','/wp-activate.php','/wp-signup.php'];
            $safe_direct_php = array_merge($safe_root_php, ['/wp-admin/admin-ajax.php','/wp-admin/admin-post.php','/wp-admin/async-upload.php','/wp-admin/load-scripts.php','/wp-admin/load-styles.php']);
            $suspicious_names = ['fe5.php','dx.php','wp.php','k.php','goods.php','gettest.php','chosen.php','abcd.php','a5.php','8.php','7.php','222.php','2.php','1.php','xroot.php','xmini.php','wp-update.php'];
            $is_root_php = strpos(ltrim($path, '/'), '/') === false;
            $is_wp_content_php = strpos($path, '/wp-content/') === 0;
            if ($is_root_php && !in_array($path, $safe_root_php, true)) { $probe_reason = 'probe:root-php'; }
            elseif (in_array($basename, $suspicious_names, true) && !in_array($path, $safe_direct_php, true)) { $probe_reason = $is_wp_content_php ? 'probe:wp-content-php' : 'probe:suspicious-php'; }
            elseif ($is_wp_content_php && in_array($basename, ['admin.php','wp.php','wp-update.php','xroot.php','xmini.php'], true)) { $probe_reason = 'probe:wp-content-php'; }
        }
    }
    $hit = false;
    if ($probe_reason !== '') { $hit = true; }
    elseif (!empty($cfg['bots_only'])) { $hit = ($ua_match && $query_match); }
    else { $hit = ($ua_match || $query_match); }
    if (!$hit) { return; }
    $summary = mls_request_shield_summary($scope, $ua_match, $query_match, $probe_reason);
    if ($cfg['action'] === 'log') { mls_log('request_shield_log', 'warning', '', mls_request_route_label($scope), $summary); return; }
    mls_log('request_shield_block', 'blocked', '', mls_request_route_label($scope), $summary);
    if (!headers_sent()) { status_header(403); nocache_headers(); header('Content-Type: text/plain; charset=utf-8'); }
    exit;
}

function mls_request_shield_run() {
    if (is_admin()) { return; }
    $cfg = mls_request_shield_settings();
    if (empty($cfg['enabled'])) { return; }
    $ip = mls_ip();
    if (mls_is_whitelisted($ip) || mls_emergency_active() || mls_is_manually_blocked($ip)) { return; }
    $scope = mls_request_route_scope();
    if (!mls_request_scope_enabled($cfg, $scope)) { return; }
    $ua = mls_current_user_agent();
    $uri = mls_current_request_uri();
    $path = strtolower((string) parse_url($uri, PHP_URL_PATH));
    if ($path === '') { $path = strtolower($uri); }
    $ua_match = !empty($cfg['ua_enabled']) ? mls_find_first_match($ua, $cfg['ua_patterns']) : '';
    $query_match = !empty($cfg['query_enabled']) ? mls_find_first_match($uri, $cfg['query_patterns']) : '';
    $probe_reason = '';
    if (!empty($cfg['probe_enabled'])) {
        $basename = strtolower((string) basename($path));
        $is_php = $basename !== '' && substr($basename, -4) === '.php';
        if ($is_php) {
            $safe_root_php = ['/index.php','/wp-login.php','/wp-cron.php','/xmlrpc.php','/wp-comments-post.php','/wp-links-opml.php','/wp-mail.php','/wp-activate.php','/wp-signup.php'];
            $safe_direct_php = array_merge($safe_root_php, ['/wp-admin/admin-ajax.php','/wp-admin/admin-post.php','/wp-admin/async-upload.php','/wp-admin/load-scripts.php','/wp-admin/load-styles.php']);
            $suspicious_names = ['fe5.php','dx.php','wp.php','k.php','goods.php','gettest.php','chosen.php','abcd.php','a5.php','8.php','7.php','222.php','2.php','1.php','xroot.php','xmini.php','wp-update.php'];
            $is_root_php = strpos(ltrim($path, '/'), '/') === false;
            $is_wp_content_php = strpos($path, '/wp-content/') === 0;
            if ($is_root_php && !in_array($path, $safe_root_php, true)) { $probe_reason = 'probe:root-php'; }
            elseif (in_array($basename, $suspicious_names, true) && !in_array($path, $safe_direct_php, true)) { $probe_reason = $is_wp_content_php ? 'probe:wp-content-php' : 'probe:suspicious-php'; }
            elseif ($is_wp_content_php && in_array($basename, ['admin.php','wp.php','wp-update.php','xroot.php','xmini.php'], true)) { $probe_reason = 'probe:wp-content-php'; }
        }
    }
    $hit = false;
    if ($probe_reason !== '') { $hit = true; }
    elseif (!empty($cfg['bots_only'])) { $hit = ($ua_match && $query_match); }
    else { $hit = ($ua_match || $query_match); }
    if (!$hit) { return; }
    $summary = mls_request_shield_summary($scope, $ua_match, $query_match, $probe_reason);
    if ($cfg['action'] === 'log') { mls_log('request_shield_log', 'warning', '', mls_request_route_label($scope), $summary); return; }
    mls_log('request_shield_block', 'blocked', '', mls_request_route_label($scope), $summary);
    if (!headers_sent()) { status_header(403); nocache_headers(); header('Content-Type: text/plain; charset=utf-8'); }
    exit('Forbidden');
}

// ─── Custom login URL routing ─────────────────────────────────────────────────

function mls_get_login_mode() {
    $s = mls_settings();
    $mode = $s['login_mode'] ?? 'whitelist';
    return in_array($mode, ['whitelist','custom','standard'], true) ? $mode : 'whitelist';
}

function mls_get_custom_slug() {
    $s = mls_settings();
    return mls_sanitize_login_slug($s['login_custom_slug'] ?? '');
}

/**
 * Lê o bypass secret do flat file.
 */
function mls_get_bypass_secret() {
    $file = trailingslashit(WP_CONTENT_DIR) . 'uploads/ml-login-secury/bypass-secret.php';
    if (!is_file($file) || !is_readable($file)) {
        mls_write_bypass_secret_export();
    }
    $secret = @include $file;
    return (is_string($secret) && strlen($secret) >= 32) ? $secret : '';
}

/**
 * Emite o cookie de bypass signed (válido 5 min, HttpOnly, SameSite=Lax).
 * Chamado antes de qualquer redirect para wp-login.php em modo custom.
 */
function mls_emit_bypass_cookie() {
    $secret = mls_get_bypass_secret();
    if ($secret === '') { return; }
    $ts   = time();
    $ip   = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    $hmac = hash_hmac('sha256', $ts . '|' . $ip, $secret);
    $val  = $ts . '.' . $hmac;
    // Expiração real: 5 minutos
    $expire = $ts + 300;
    // Usar setcookie com SameSite=Lax via header para compatibilidade PHP 7.4+
    $cookie_path = '/';
    $domain      = '';
    $secure      = is_ssl();
    if (PHP_VERSION_ID >= 70300) {
        setcookie('mls_cx', $val, [
            'expires'  => $expire,
            'path'     => $cookie_path,
            'domain'   => $domain,
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        $secure_flag = $secure ? '; Secure' : '';
        header('Set-Cookie: mls_cx=' . rawurlencode($val) . '; Path=' . $cookie_path . '; Expires=' . gmdate('D, d M Y H:i:s T', $expire) . '; HttpOnly; SameSite=Lax' . $secure_flag, false);
    }
}

/**
 * Intercepta o custom slug no init (priority 1).
 * Emite cookie de bypass e redireciona para wp-login.php nativo.
 * Suporta GET (exibição do form) e POST (submit das credenciais),
 * incluindo logout, lost-password e redirect_to.
 */
add_action('init', function () {
    if (mls_get_login_mode() !== 'custom') { return; }

    $slug = mls_get_custom_slug();
    if ($slug === '') { return; }

    $uri          = (string) ($_SERVER['REQUEST_URI'] ?? '');
    $path         = strtolower(rtrim((string) parse_url($uri, PHP_URL_PATH), '/'));
    $slug_path    = strtolower('/' . ltrim($slug, '/'));
    $slug_clean   = rtrim($slug_path, '/');

    if ($path !== $slug_clean) { return; }

    // Rate limiting por IP antes de emitir o cookie
    $ip = mls_ip();
    $s  = mls_settings();
    if (!mls_is_whitelisted($ip) && !mls_emergency_active()) {
        $key   = 'mls_clogin_' . md5($ip);
        $count = (int) get_transient($key);
        if ($count >= max(5, (int) ($s['max_attempts'] ?? 5) * 2)) {
            status_header(429);
            nocache_headers();
            exit('Too many requests.');
        }
        set_transient($key, $count + 1, max(60, (int) ($s['time_window_minutes'] ?? 15) * 60));
    }

    // Emitir cookie de bypass — autoriza o early-block a deixar wp-login.php passar
    mls_emit_bypass_cookie();

    // Montar URL de destino em wp-login.php.
    // Preservar redirect_to original se presente.
    // Se ausente, injetar admin_url() — evita que WordPress use home_url()
    // para usuários cujo perfil não tem backend access explícito.
    $qs_raw  = (string) ($_SERVER['QUERY_STRING'] ?? '');
    parse_str($qs_raw, $mls_qs_params);

    if (empty($mls_qs_params['redirect_to'])) {
        $mls_qs_params['redirect_to'] = admin_url();
    }

    // Preservar action se presente (logout, lostpassword, etc)
    $mls_login_target = site_url('wp-login.php') . '?' . http_build_query($mls_qs_params);

    nocache_headers();
    wp_redirect($mls_login_target, 302);
    exit;
}, 1);

// ─── Activation ──────────────────────────────────────────────────────────────

register_activation_hook(__FILE__, function () {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();

    dbDelta("CREATE TABLE {$wpdb->prefix}" . MLS_LOG_TABLE . " (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        created_at DATETIME NOT NULL,
        ip VARCHAR(45) NOT NULL,
        username VARCHAR(191) NOT NULL DEFAULT '',
        event_type VARCHAR(50) NOT NULL,
        status VARCHAR(30) NOT NULL DEFAULT '',
        route VARCHAR(50) NOT NULL DEFAULT '',
        details TEXT NULL,
        user_agent VARCHAR(255) NOT NULL DEFAULT ''
    ) $charset;");

    dbDelta("CREATE TABLE {$wpdb->prefix}" . MLS_LOCK_TABLE . " (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(45) NOT NULL,
        username VARCHAR(191) NOT NULL DEFAULT '',
        attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
        expires_at DATETIME NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        KEY idx_ip (ip),
        KEY idx_active (is_active)
    ) $charset;");

    dbDelta("CREATE TABLE {$wpdb->prefix}" . MLS_MANUAL_BLOCK_TABLE . " (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(45) NOT NULL,
        created_at DATETIME NOT NULL,
        reason VARCHAR(191) NOT NULL DEFAULT '',
        UNIQUE KEY uniq_ip (ip)
    ) $charset;");

    if (!get_option(MLS_OPTION_KEY)) {
        add_option(MLS_OPTION_KEY, mls_defaults());
    }

    mls_write_mu_loader();
    mls_write_all_flat_exports(mls_settings());
});

// ─── Admin init ───────────────────────────────────────────────────────────────

add_action('admin_init', function () {
    if (!current_user_can('manage_options')) { return; }
    if (!file_exists(mls_mu_loader_path())) { mls_write_mu_loader(); }
    if (!file_exists(mls_login_whitelist_export_path())) { mls_write_all_flat_exports(mls_settings()); }
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_mls-dashboard') return;
    wp_enqueue_style('mls-admin', plugin_dir_url(__FILE__) . 'assets/css/admin.css', [], MLS_VERSION);
    wp_enqueue_script('mls-admin', plugin_dir_url(__FILE__) . 'assets/js/admin.js', [], MLS_VERSION, true);
});

// ─── Log helper ───────────────────────────────────────────────────────────────

function mls_log($event, $status, $user = '', $route = '', $details = '') {
    global $wpdb;
    $wpdb->insert($wpdb->prefix . MLS_LOG_TABLE, [
        'created_at' => mls_now(), 'ip' => mls_ip(), 'username' => $user,
        'event_type' => $event, 'status' => $status, 'route' => $route,
        'details' => $details, 'user_agent' => mls_current_user_agent(),
    ]);
    mls_maybe_send_alert_email($event);
}

// ─── Runtime hooks ────────────────────────────────────────────────────────────

mls_request_shield_early_intercept();

add_action('plugins_loaded', 'mls_request_shield_run', 0);

add_filter('authenticate', function ($user, $username, $password) {
    global $wpdb;
    $s = mls_settings();
    $ip = mls_ip();
    if ($s['mode'] === 'learn' || mls_is_whitelisted($ip) || mls_emergency_active()) { return $user; }
    if (mls_is_manually_blocked($ip)) { return new WP_Error('mls_manual_block', 'Blocked by security policy.'); }
    $active = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}" . MLS_LOCK_TABLE . " WHERE ip=%s AND is_active=1 AND expires_at>%s LIMIT 1", $ip, mls_now()));
    if ($active) { return new WP_Error('mls_locked', 'Too many attempts. Try again later.'); }
    return $user;
}, 5, 3);

add_action('wp_login_failed', function ($username) {
    global $wpdb;
    $s = mls_settings();
    $ip = mls_ip();
    if ($s['mode'] === 'learn' || mls_is_whitelisted($ip) || mls_emergency_active() || mls_is_manually_blocked($ip)) { return; }
    $key = 'mls_attempt_' . md5($ip);
    $count = (int) get_transient($key) + 1;
    set_transient($key, $count, max(60, $s['time_window_minutes'] * 60));
    mls_log('login_failure', 'failed', $username, 'wp-login.php', 'invalid_credentials');
    if ($count >= $s['max_attempts']) {
        $wpdb->insert($wpdb->prefix . MLS_LOCK_TABLE, ['ip'=>$ip,'username'=>$username,'attempt_count'=>$count,'expires_at'=>date('Y-m-d H:i:s', time()+($s['base_lock_minutes']*60)),'is_active'=>1]);
        mls_log('lockout_created', 'blocked', $username, 'wp-login.php', 'limit_reached');
        if (mls_recurrence_should_block($ip) && !mls_is_manually_blocked($ip)) {
            $wpdb->replace($wpdb->prefix . MLS_MANUAL_BLOCK_TABLE, ['ip'=>$ip,'created_at'=>mls_now(),'reason'=>'auto_recurrence_block']);
            mls_log('auto_manual_block', 'blocked', $username, 'wp-login.php', 'recurrence_auto_block');
        }
    }
});

add_action('wp_login', function () { delete_transient('mls_attempt_' . md5(mls_ip())); });

add_filter('xmlrpc_enabled', function ($enabled) {
    $s = mls_settings();
    return (($s['xmlrpc_mode'] ?? 'limit') === 'block') ? false : $enabled;
});

add_action('init', function () {
    $s = mls_settings();
    $uri = sanitize_text_field($_SERVER['REQUEST_URI'] ?? '');
    if (strpos($uri, 'xmlrpc.php') === false) return;
    $ip = mls_ip();
    if (mls_is_whitelisted($ip) || mls_emergency_active()) return;
    if (mls_is_manually_blocked($ip)) { status_header(403); exit('Blocked by security policy.'); }
    if (($s['xmlrpc_mode'] ?? 'limit') === 'off') return;
    mls_log('xmlrpc_request', 'warning', '', 'xmlrpc.php', 'xmlrpc_hit');
    if (($s['xmlrpc_mode'] ?? 'limit') === 'block') { mls_log('xmlrpc_blocked', 'blocked', '', 'xmlrpc.php', 'blocked_by_plugin'); status_header(403); exit('XML-RPC blocked.'); }
    if (($s['xmlrpc_mode'] ?? 'limit') === 'limit') {
        $key = 'mls_xmlrpc_' . md5($ip);
        $count = (int) get_transient($key) + 1;
        set_transient($key, $count, 900);
        if ($count >= 10) {
            mls_log('xmlrpc_blocked', 'blocked', '', 'xmlrpc.php', 'xmlrpc_limit_reached');
            if (mls_recurrence_should_block($ip) && !mls_is_manually_blocked($ip)) {
                global $wpdb;
                $wpdb->replace($wpdb->prefix . MLS_MANUAL_BLOCK_TABLE, ['ip'=>$ip,'created_at'=>mls_now(),'reason'=>'auto_recurrence_block']);
                mls_log('auto_manual_block', 'blocked', '', 'xmlrpc.php', 'recurrence_auto_block');
            }
            status_header(429); exit('Too many XML-RPC requests.');
        }
    }
}, 0);

// ─── Admin export actions ─────────────────────────────────────────────────────

add_action('admin_init', function () {
    if (!is_admin() || empty($_GET['page']) || $_GET['page'] !== 'mls-dashboard') return;

    if (isset($_GET['mls_export_logs'])) {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " ORDER BY id DESC LIMIT 500", ARRAY_A);
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=ml-login-secury-logs.csv');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Data','IP','Usuario','Evento','Status','Rota','Detalhes','User Agent'], ';');
        foreach ($rows as $row) { fputcsv($out, [$row['created_at'],$row['ip'],$row['username'],$row['event_type'],$row['status'],$row['route'],$row['details'],$row['user_agent']], ';'); }
        fclose($out);
        exit;
    }

    if (isset($_GET['mls_export_settings'])) {
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=ml-login-secury-settings.json');
        echo wp_json_encode(mls_settings(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
});

// ─── Admin menu ───────────────────────────────────────────────────────────────

add_action('admin_menu', function () {
    add_menu_page('ML Login Secury', 'ML Login Secury', 'manage_options', 'mls-dashboard', 'mls_admin', 'dashicons-shield', 58);
});

// ─── Admin UI helpers ─────────────────────────────────────────────────────────

function mls_tab_nav($tab) {
    $tabs = ['dashboard'=>'Dashboard','protection'=>'Proteção','login_mode'=>'Modo de Login','request_shield'=>'Request Shield','whitelist'=>'Whitelist','lockouts'=>'Bloqueios','logs'=>'Logs','license'=>'Licença'];
    echo '<div class="mls-shell__tabs">';
    foreach ($tabs as $k => $label) {
        $cls = $tab === $k ? ' is-active' : '';
        echo '<a class="mls-shell__tab' . $cls . '" href="?page=mls-dashboard&tab=' . $k . '">' . $label . '</a>';
    }
    echo '</div>';
}

function mls_toast_placeholder($type, $message) {
    if (!$message) return;
    echo '<div class="mls-toast-source" data-type="' . esc_attr($type) . '" data-message="' . esc_attr($message) . '"></div>';
}

function mls_header($title) {
    echo '<div class="mls-shell__hero"><div class="mls-shell__brand"><div class="mls-shell__mark"><img src="' . mls_logo_url() . '" alt="ML Lopes Design"></div><div class="mls-shell__copy"><span class="mls-shell__eyebrow">ML LOGIN SECURY</span><h1>' . $title . '</h1><p>Proteção de login multi-modo, XML-RPC, Request Shield, bloqueios, alertas e leitura operacional de ataques.</p></div></div><div class="mls-shell__meta"><div class="mls-shell__version">v' . MLS_VERSION . '</div><div class="mls-shell__tags"><span class="mls-shell__tag">Deploy Clientes</span><span class="mls-shell__tag">Modo Whitelist</span><span class="mls-shell__tag">URL Personalizada</span></div></div></div>';
}

function mls_card($title, $value, $accent = 'blue') {
    echo '<div class="mls-stat mls-stat-' . $accent . '"><span>' . $title . '</span><strong>' . $value . '</strong></div>';
}

function mls_ip_card() {
    $ip = mls_ip();
    $type = mls_guess_ip_type($ip);
    echo '<div class="mls-stat mls-stat-blue mls-stat-ip"><span>Meu IP atual</span><strong>' . esc_html($ip) . '</strong><em class="mls-ip-badge">Tipo: ' . esc_html($type) . '</em></div>';
}

// ─── Admin controller ─────────────────────────────────────────────────────────

function mls_admin() {
    global $wpdb;
    $tab = sanitize_key($_GET['tab'] ?? 'dashboard');
    $s = mls_settings();
    $toast_type = '';
    $toast_message = '';

    // 2.2.0: sem teste/licença, as ações que gravam configurações são descartadas aqui
    // (a proteção do site não depende disto e continua funcionando igual).
    if (MLS_License::filter_admin_request()) {
        $toast_type = 'error';
        $toast_message = MLS_License::locked_message();
    }

    // ── Save settings ──
    if (isset($_POST['mls_save'])) {
        check_admin_referer('mls_save_settings');

        if ($tab === 'protection') {
            $s['mode'] = sanitize_text_field($_POST['mode'] ?? $s['mode']);
            if (!in_array($s['mode'], ['learn','limit','full'], true)) $s['mode'] = 'limit';
            $s['xmlrpc_mode'] = sanitize_text_field($_POST['xmlrpc_mode'] ?? $s['xmlrpc_mode']);
            if (!in_array($s['xmlrpc_mode'], ['off','limit','block'], true)) $s['xmlrpc_mode'] = 'limit';
            $s['max_attempts'] = max(2, intval($_POST['max_attempts'] ?? $s['max_attempts']));
            $s['time_window_minutes'] = max(1, intval($_POST['time_window_minutes'] ?? $s['time_window_minutes']));
            $s['base_lock_minutes'] = max(1, intval($_POST['base_lock_minutes'] ?? $s['base_lock_minutes']));
            $s['alert_email'] = sanitize_email($_POST['alert_email'] ?? '');
            $s['alert_threshold'] = max(1, intval($_POST['alert_threshold'] ?? $s['alert_threshold']));
            $s['recurrence_lockouts'] = max(1, intval($_POST['recurrence_lockouts'] ?? $s['recurrence_lockouts']));

        } elseif ($tab === 'login_mode') {
            $new_mode = sanitize_text_field($_POST['login_mode'] ?? 'whitelist');
            if (!in_array($new_mode, ['whitelist','custom','standard'], true)) $new_mode = 'whitelist';
            $s['login_mode'] = $new_mode;
            $raw_slug = sanitize_text_field($_POST['login_custom_slug'] ?? '');
            $s['login_custom_slug'] = mls_sanitize_login_slug($raw_slug);
            $behavior = sanitize_text_field($_POST['login_original_behavior'] ?? '403');
            if (!in_array($behavior, ['403','404','home'], true)) $behavior = '403';
            $s['login_original_behavior'] = $behavior;
            $s['throttle_window']  = max(60,  intval($_POST['throttle_window']  ?? ($s['throttle_window']  ?? 300)));
            $s['throttle_limit']   = max(3,   intval($_POST['throttle_limit']   ?? ($s['throttle_limit']   ?? 8)));
            $s['throttle_lockout'] = max(300, intval($_POST['throttle_lockout'] ?? ($s['throttle_lockout'] ?? 900)));

        } elseif ($tab === 'request_shield') {
            $s['request_shield_enabled'] = mls_bool_setting($_POST['request_shield_enabled'] ?? 0);
            $s['request_shield_user_agent_enabled'] = mls_bool_setting($_POST['request_shield_user_agent_enabled'] ?? 0);
            $s['request_shield_query_enabled'] = mls_bool_setting($_POST['request_shield_query_enabled'] ?? 0);
            $s['request_shield_probe_enabled'] = mls_bool_setting($_POST['request_shield_probe_enabled'] ?? 0);
            $s['request_shield_bots_only'] = mls_bool_setting($_POST['request_shield_bots_only'] ?? 0);
            $s['request_shield_route_front'] = mls_bool_setting($_POST['request_shield_route_front'] ?? 0);
            $s['request_shield_route_login'] = mls_bool_setting($_POST['request_shield_route_login'] ?? 0);
            $s['request_shield_route_xmlrpc'] = mls_bool_setting($_POST['request_shield_route_xmlrpc'] ?? 0);
            $s['request_shield_route_ajax'] = mls_bool_setting($_POST['request_shield_route_ajax'] ?? 0);
            $s['request_shield_route_cron'] = mls_bool_setting($_POST['request_shield_route_cron'] ?? 0);
            $s['request_shield_action'] = sanitize_text_field($_POST['request_shield_action'] ?? ($s['request_shield_action'] ?? 'block'));
            if (!in_array($s['request_shield_action'], ['log','block'], true)) $s['request_shield_action'] = 'block';
            $s['request_shield_ua_patterns'] = mls_clean_pattern_lines($_POST['request_shield_ua_patterns'] ?? implode("\n", (array) ($s['request_shield_ua_patterns'] ?? [])));
            $s['request_shield_query_patterns'] = mls_clean_pattern_lines($_POST['request_shield_query_patterns'] ?? implode("\n", (array) ($s['request_shield_query_patterns'] ?? [])));

        } elseif ($tab === 'whitelist') {
            $s['whitelist_ips'] = mls_clean_ip_list($_POST['whitelist_ips'] ?? implode("\n", (array) ($s['whitelist_ips'] ?? [])));
            $s['login_emergency_duration_minutes'] = max(5, intval($_POST['login_emergency_duration_minutes'] ?? ($s['login_emergency_duration_minutes'] ?? 60)));
            if (!empty($_POST['mls_regenerate_emergency_token'])) {
                $s['login_emergency_token'] = mls_generate_emergency_token();
            } elseif (empty($s['login_emergency_token'])) {
                $s['login_emergency_token'] = mls_generate_emergency_token();
            }
        }

        update_option(MLS_OPTION_KEY, $s, false);
        mls_write_all_flat_exports($s);
        $toast_type = 'success';
        $toast_message = 'Configurações salvas.';
    }

    if (isset($_POST['mls_import_settings'])) {
        check_admin_referer('mls_save_settings');
        if (!empty($_FILES['mls_settings_file']['tmp_name'])) {
            $json = file_get_contents($_FILES['mls_settings_file']['tmp_name']);
            $data = json_decode($json, true);
            if (is_array($data)) {
                $merged = wp_parse_args($data, mls_defaults());
                $merged['whitelist_ips'] = mls_clean_ip_list(implode("\n", (array) ($merged['whitelist_ips'] ?? [])));
                if (empty($merged['login_emergency_token'])) { $merged['login_emergency_token'] = mls_generate_emergency_token(); }
                $merged['login_emergency_duration_minutes'] = max(5, (int) ($merged['login_emergency_duration_minutes'] ?? 60));
                update_option(MLS_OPTION_KEY, $merged, false);
                $s = mls_settings();
                mls_write_all_flat_exports($s);
                $toast_type = 'success';
                $toast_message = 'Configurações importadas.';
            } else {
                $toast_type = 'error';
                $toast_message = 'JSON inválido para importação.';
            }
        }
    }

    if (isset($_POST['mls_add_current_ip'])) {
        check_admin_referer('mls_save_settings');
        $list = mls_clean_ip_list(implode("\n", (array) $s['whitelist_ips']) . "\n" . mls_ip());
        $s['whitelist_ips'] = $list;
        update_option(MLS_OPTION_KEY, $s, false);
        mls_write_all_flat_exports($s);
        $toast_type = 'success';
        $toast_message = 'IP atual adicionado à whitelist.';
    }

    if (isset($_GET['mls_quick_whitelist_ip'])) {
        $ip = sanitize_text_field($_GET['mls_quick_whitelist_ip']);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            $list = mls_clean_ip_list(implode("\n", (array) $s['whitelist_ips']) . "\n" . $ip);
            $s['whitelist_ips'] = $list;
            update_option(MLS_OPTION_KEY, $s, false);
            mls_write_all_flat_exports($s);
            $toast_type = 'success';
            $toast_message = 'IP enviado para whitelist.';
        }
    }

    if (isset($_POST['mls_emergency_open'])) {
        check_admin_referer('mls_save_settings');
        $s['emergency_until'] = date('Y-m-d H:i:s', time() + 900);
        update_option(MLS_OPTION_KEY, $s, false);
        mls_write_all_flat_exports($s);
        $toast_type = 'success';
        $toast_message = 'Emergência liberada por 15 minutos.';
    }

    if (isset($_POST['mls_emergency_close'])) {
        check_admin_referer('mls_save_settings');
        $s['emergency_until'] = '';
        update_option(MLS_OPTION_KEY, $s, false);
        mls_write_all_flat_exports($s);
        $toast_type = 'success';
        $toast_message = 'Emergência encerrada.';
    }

    if (isset($_POST['mls_clear_logs'])) {
        check_admin_referer('mls_save_settings');
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}" . MLS_LOG_TABLE);
        $toast_type = 'success';
        $toast_message = 'Logs limpos.';
    }

    if (isset($_POST['mls_manual_block_ip'])) {
        check_admin_referer('mls_save_settings');
        $manual_ip = sanitize_text_field($_POST['manual_block_ip'] ?? '');
        if (filter_var($manual_ip, FILTER_VALIDATE_IP)) {
            $wpdb->replace($wpdb->prefix . MLS_MANUAL_BLOCK_TABLE, ['ip'=>$manual_ip,'created_at'=>mls_now(),'reason'=>'manual_admin_block']);
            $toast_type = 'success';
            $toast_message = 'IP bloqueado manualmente.';
        } else {
            $toast_type = 'error';
            $toast_message = 'IP inválido para bloqueio manual.';
        }
    }

    if (isset($_GET['mls_quick_block_ip'])) {
        $manual_ip = sanitize_text_field($_GET['mls_quick_block_ip']);
        if (filter_var($manual_ip, FILTER_VALIDATE_IP)) {
            $wpdb->replace($wpdb->prefix . MLS_MANUAL_BLOCK_TABLE, ['ip'=>$manual_ip,'created_at'=>mls_now(),'reason'=>'manual_admin_block']);
            $toast_type = 'success';
            $toast_message = 'IP bloqueado manualmente.';
        }
    }

    if (isset($_GET['unblock_manual_ip'])) {
        $wpdb->delete($wpdb->prefix . MLS_MANUAL_BLOCK_TABLE, ['ip'=>sanitize_text_field($_GET['unblock_manual_ip'])]);
        $toast_type = 'success';
        $toast_message = 'IP removido da blacklist manual.';
    }

    if (isset($_GET['unlock_ip'])) {
        $wpdb->update($wpdb->prefix . MLS_LOCK_TABLE, ['is_active'=>0], ['ip'=>sanitize_text_field($_GET['unlock_ip'])]);
        $toast_type = 'success';
        $toast_message = 'IP desbloqueado.';
    }

    if (isset($_GET['unlock_all'])) {
        $wpdb->query("UPDATE {$wpdb->prefix}" . MLS_LOCK_TABLE . " SET is_active=0");
        $toast_type = 'success';
        $toast_message = 'Todos os bloqueios foram removidos.';
    }

    $log_route = sanitize_text_field($_GET['log_route'] ?? '');
    $log_status = sanitize_text_field($_GET['log_status'] ?? '');
    $log_search = sanitize_text_field($_GET['log_search'] ?? '');
    $log_event = sanitize_text_field($_GET['log_event'] ?? '');
    $lock_ip_filter = sanitize_text_field($_GET['lock_ip_filter'] ?? '');

    echo '<div class="wrap mls-shell"><div class="mls-notice-stack" aria-live="polite" aria-atomic="true"></div>';
    mls_toast_placeholder($toast_type, $toast_message);
    if (!empty($_GET['mls_notice'])) {
        mls_toast_placeholder(sanitize_key($_GET['mls_notice_type'] ?? '') === 'error' ? 'error' : 'success', sanitize_text_field(wp_unslash($_GET['mls_notice'])));
    }
    mls_header($tab === 'license' ? 'Licença' : 'Configurações globais');
    mls_tab_nav($tab);
    if ($tab !== 'license') { MLS_License::render_locked_notice(); }

    // ── Dashboard tab ──
    if ($tab === 'dashboard') {
        $active = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}" . MLS_LOCK_TABLE . " WHERE is_active=1 AND expires_at>'" . mls_now() . "'");
        $today = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE DATE(created_at)=CURDATE()");
        $login_hits = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE route='wp-login.php' AND DATE(created_at)=CURDATE()");
        $xmlrpc = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE route='xmlrpc.php' AND DATE(created_at)=CURDATE()");
        $top_attackers = $wpdb->get_results("SELECT ip, COUNT(*) as total FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " GROUP BY ip ORDER BY total DESC LIMIT 10");

        $mode_labels = ['whitelist'=>'Whitelist-only','custom'=>'URL personalizada','standard'=>'Login padrão protegido'];
        $current_mode = $s['login_mode'] ?? 'whitelist';
        $current_mode_label = $mode_labels[$current_mode] ?? 'Whitelist-only';

        echo '<div class="mls-stats">';
        mls_card('Eventos hoje', $today, 'blue');
        mls_card('Ataques login hoje', $login_hits, 'red');
        mls_card('Ataques XML-RPC hoje', $xmlrpc, 'dark');
        mls_card('Bloqueios ativos', $active, 'green');
        echo '</div>';

        echo '<div class="mls-stats mls-stats--secondary">';
        mls_card('Modo de login', esc_html($current_mode_label), 'blue');
        mls_card('Alert e-mail', $s['alert_email'] ? esc_html($s['alert_email']) : 'não definido', 'green');
        mls_card('Reincidência auto block', (int) $s['recurrence_lockouts'] . ' lockouts', 'dark');
        mls_ip_card();
        echo '</div>';

        echo '<div class="mls-panel"><div class="mls-panel-head"><h2>Top 10 IPs mais agressivos</h2></div><table class="widefat striped mls-table"><thead><tr><th>IP</th><th>Reincidência</th><th>Login</th><th>XML-RPC</th><th>Score</th><th>Nível</th></tr></thead><tbody>';
        if ($top_attackers) {
            foreach ($top_attackers as $row) {
                $counts = mls_get_ip_event_counts($row->ip);
                $score = mls_calculate_risk_score($row->ip);
                echo '<tr><td>' . esc_html($row->ip) . '</td><td>' . (int)$row->total . '</td><td>' . (int)$counts['login_failure'] . '</td><td>' . ((int)$counts['xmlrpc_request'] + (int)$counts['xmlrpc_blocked']) . '</td><td>' . (int)$score . '</td><td>' . esc_html(mls_risk_label($score)) . '</td></tr>';
            }
        } else {
            echo '<tr><td colspan="6">Nenhum IP agressivo registrado ainda.</td></tr>';
        }
        echo '</tbody></table></div>';

    // ── Protection tab ──
    } elseif ($tab === 'protection') {
        echo '<form method="post" class="mls-panel">';
        wp_nonce_field('mls_save_settings');
        echo '<h2>Proteção</h2><div class="mls-form-grid">';
        echo '<div class="mls-field"><label>Modo de proteção</label><select name="mode"><option value="learn" ' . selected($s['mode'], 'learn', false) . '>Learn</option><option value="limit" ' . selected($s['mode'], 'limit', false) . '>Limit</option><option value="full" ' . selected($s['mode'], 'full', false) . '>Full</option></select></div>';
        echo '<div class="mls-field"><label>Máximo de tentativas</label><input type="number" name="max_attempts" value="' . (int)$s['max_attempts'] . '"></div>';
        echo '<div class="mls-field"><label>Janela de tentativas (minutos)</label><input type="number" name="time_window_minutes" value="' . (int)$s['time_window_minutes'] . '"></div>';
        echo '<div class="mls-field"><label>Tempo de bloqueio (minutos)</label><input type="number" name="base_lock_minutes" value="' . (int)$s['base_lock_minutes'] . '"></div>';
        echo '<div class="mls-field"><label>Modo XML-RPC</label><select name="xmlrpc_mode"><option value="off" ' . selected($s['xmlrpc_mode'], 'off', false) . '>Off</option><option value="limit" ' . selected($s['xmlrpc_mode'], 'limit', false) . '>Limit</option><option value="block" ' . selected($s['xmlrpc_mode'], 'block', false) . '>Block</option></select></div>';
        echo '<div class="mls-field"><label>E-mail de alerta</label><input type="email" name="alert_email" value="' . esc_attr($s['alert_email']) . '" placeholder="voce@dominio.com"></div>';
        echo '<div class="mls-field"><label>Threshold de alerta</label><input type="number" name="alert_threshold" value="' . (int)$s['alert_threshold'] . '"><small>Eventos em 15 minutos para disparar e-mail.</small></div>';
        echo '<div class="mls-field"><label>Reincidência para auto block</label><input type="number" name="recurrence_lockouts" value="' . (int)$s['recurrence_lockouts'] . '"><small>Quantidade de lockouts do mesmo IP para virar blacklist manual.</small></div>';
        echo '</div><p><button class="mls-action-button" type="submit" name="mls_save" value="1">Salvar Configurações</button></p></form>';

        echo '<div class="mls-panel"><div class="mls-panel-head"><h2>Importar / Exportar Configurações</h2><a class="mls-action-button mls-action-button--secondary" href="?page=mls-dashboard&tab=protection&mls_export_settings=1">Exportar JSON</a></div><form method="post" enctype="multipart/form-data">';
        wp_nonce_field('mls_save_settings');
        echo '<div class="mls-field"><label>Importar JSON</label><input type="file" name="mls_settings_file" accept=".json,application/json"></div><p><button class="mls-action-button" type="submit" name="mls_import_settings" value="1">Importar Configurações</button></p></form></div>';

    // ── Login Mode tab ──
    } elseif ($tab === 'login_mode') {
        $current_login_mode = $s['login_mode'] ?? 'whitelist';
        $custom_slug = mls_sanitize_login_slug($s['login_custom_slug'] ?? '');
        $original_behavior = $s['login_original_behavior'] ?? '403';
        $site_url = rtrim(home_url(), '/');
        $tw  = (int) ($s['throttle_window']  ?? 300);
        $tl  = (int) ($s['throttle_limit']   ?? 8);
        $tlo = (int) ($s['throttle_lockout'] ?? 900);

        echo '<form method="post" class="mls-panel">';
        wp_nonce_field('mls_save_settings');
        echo '<div class="mls-panel-head"><h2>Modo de Proteção do Login</h2></div>';

        echo '<div class="mls-login-mode-grid">';

        $m1_active = $current_login_mode === 'whitelist' ? ' mls-mode-card--active' : '';
        echo '<label class="mls-mode-card' . $m1_active . '">';
        echo '<input type="radio" name="login_mode" value="whitelist" ' . checked($current_login_mode, 'whitelist', false) . '>';
        echo '<div class="mls-mode-card__head"><strong>Whitelist-only</strong><span class="mls-mode-badge mls-mode-badge--red">Máxima segurança</span></div>';
        echo '<p>Ideal para sites gerenciados somente pelo administrador. O acesso ao login e ao wp-admin é bloqueado para todos os IPs não autorizados. Nenhum ataque passa para o PHP.</p>';
        echo '</label>';

        $m2_active = $current_login_mode === 'custom' ? ' mls-mode-card--active' : '';
        echo '<label class="mls-mode-card' . $m2_active . '">';
        echo '<input type="radio" name="login_mode" value="custom" ' . checked($current_login_mode, 'custom', false) . '>';
        echo '<div class="mls-mode-card__head"><strong>URL de login personalizada</strong><span class="mls-mode-badge mls-mode-badge--blue">Sites de clientes</span></div>';
        echo '<p>Ideal para sites com usuários não técnicos. Cria uma URL exclusiva de login. O wp-login.php original é bloqueado. Acessos hostis ao wp-admin são throttled e cortados antes do loop de redirect.</p>';
        echo '</label>';

        $m3_active = $current_login_mode === 'standard' ? ' mls-mode-card--active' : '';
        echo '<label class="mls-mode-card' . $m3_active . '">';
        echo '<input type="radio" name="login_mode" value="standard" ' . checked($current_login_mode, 'standard', false) . '>';
        echo '<div class="mls-mode-card__head"><strong>Protegido sem whitelist</strong><span class="mls-mode-badge mls-mode-badge--green">Clientes / compatibilidade</span></div>';
        echo '<p>Mantém o wp-login.php acessível, mas aplica throttle e lockout reais por IP para wp-login.php e wp-admin. Para acessos suspeitos repetidos, bloqueia antes de atingir o WordPress.</p>';
        echo '</label>';

        echo '</div>';

        echo '<div class="mls-form-grid" style="margin-top:28px;">';

        echo '<div class="mls-field">';
        echo '<label>Slug de login personalizado</label>';
        echo '<div class="mls-url-preview"><span>' . esc_html($site_url) . '/</span><input type="text" name="login_custom_slug" value="' . esc_attr($custom_slug) . '" placeholder="meu-acesso" ' . ($current_login_mode !== 'custom' ? 'disabled' : '') . '></div>';
        echo '<small>Somente letras minúsculas, números e hífens. Exemplo: <code>painel-cliente</code>, <code>entrar-seguro</code>.</small>';
        echo '</div>';

        echo '<div class="mls-field">';
        echo '<label>Comportamento do wp-login.php original</label>';
        echo '<select name="login_original_behavior" ' . ($current_login_mode !== 'custom' ? 'disabled' : '') . '>';
        echo '<option value="403" ' . selected($original_behavior, '403', false) . '>Retornar 403 Forbidden</option>';
        echo '<option value="404" ' . selected($original_behavior, '404', false) . '>Retornar 404 Not Found</option>';
        echo '<option value="home" ' . selected($original_behavior, 'home', false) . '>Redirecionar para home</option>';
        echo '</select>';
        echo '<small>O que acontece quando alguém acessa wp-login.php diretamente no modo URL personalizada.</small>';
        echo '</div>';

        echo '</div>';

        // Throttle config — visible only in standard/custom modes
        $tvis = $current_login_mode !== 'whitelist' ? '' : ' style="opacity:.5;pointer-events:none;"';
        echo '<div class="mls-panel mls-panel--inner" style="margin-top:24px;"' . $tvis . '>';
        echo '<h3 class="mls-subtitle">Throttle e lockout — modos protegido e URL personalizada</h3>';
        echo '<p style="font-size:13px;color:var(--mls-muted);margin:0 0 18px;">Esses parâmetros controlam o bloqueio early de IPs hostis que tentam /wp-login.php e /wp-admin/* repetidamente.</p>';
        echo '<div class="mls-form-grid">';
        echo '<div class="mls-field"><label>Janela de contagem (segundos)</label><input type="number" name="throttle_window" min="60" value="' . $tw . '"><small>Período de observação por IP. Padrão: 300s (5 min).</small></div>';
        echo '<div class="mls-field"><label>Requests antes de bloquear</label><input type="number" name="throttle_limit" min="3" value="' . $tl . '"><small>Acessos hostis ao login/admin dentro da janela antes do lockout. Padrão: 8.</small></div>';
        echo '<div class="mls-field"><label>Duração do lockout (segundos)</label><input type="number" name="throttle_lockout" min="300" value="' . $tlo . '"><small>Tempo de bloqueio após atingir o limite. Padrão: 900s (15 min).</small></div>';
        echo '</div></div>';

        if ($current_login_mode === 'custom' && $custom_slug !== '') {
            echo '<div class="mls-info-box" style="margin-top:20px;padding:16px 20px;background:#eaf5f7;border:1px solid #bfd6dc;border-radius:14px;">';
            echo '<strong>URL de login ativa:</strong> <code>' . esc_html($site_url . '/' . $custom_slug) . '</code>';
            echo '</div>';
        }

        echo '<p style="margin-top:24px;"><button class="mls-action-button" type="submit" name="mls_save" value="1">Salvar Configurações</button></p>';
        echo '</form>';

    // ── Request Shield tab ──
    } elseif ($tab === 'request_shield') {
        echo '<form method="post" class="mls-panel">';
        wp_nonce_field('mls_save_settings');
        echo '<div class="mls-panel-head"><h2>Request Shield</h2><div class="mls-mini-list"><div><strong>Objetivo:</strong> segurar bots + query strings caras antes do WordPress ficar pesado.</div><div><strong>Estratégia:</strong> substring match leve, config em memória por request, deny curto.</div></div></div>';
        echo '<div class="mls-grid-2 mls-grid-2--equal">';
        echo '<div class="mls-panel mls-panel--inner"><h3 class="mls-subtitle">Ativação e regras</h3><div class="mls-toggle-list">';
        echo '<label class="mls-toggle-row"><input type="checkbox" name="request_shield_enabled" value="1" ' . checked(!empty($s['request_shield_enabled']), true, false) . '><span>Ativar Request Shield</span></label>';
        echo '<label class="mls-toggle-row"><input type="checkbox" name="request_shield_user_agent_enabled" value="1" ' . checked(!empty($s['request_shield_user_agent_enabled']), true, false) . '><span>Detectar por User-Agent</span></label>';
        echo '<label class="mls-toggle-row"><input type="checkbox" name="request_shield_query_enabled" value="1" ' . checked(!empty($s['request_shield_query_enabled']), true, false) . '><span>Detectar por Query String</span></label>';
        echo '<label class="mls-toggle-row"><input type="checkbox" name="request_shield_bots_only" value="1" ' . checked(!empty($s['request_shield_bots_only']), true, false) . '><span>Modo bots only (UA + query)</span></label>';
        echo '<label class="mls-toggle-row"><input type="checkbox" name="request_shield_probe_enabled" value="1" ' . checked(!empty($s['request_shield_probe_enabled']), true, false) . '><span>Bloquear probes PHP maliciosos</span></label>';
        echo '</div>';
        echo '<div class="mls-field"><label>Ação</label><select name="request_shield_action"><option value="log" ' . selected(($s['request_shield_action'] ?? 'block'), 'log', false) . '>Log only</option><option value="block" ' . selected(($s['request_shield_action'] ?? 'block'), 'block', false) . '>Block 403</option></select></div>';
        echo '<h3 class="mls-subtitle">Onde aplicar proteção</h3><div class="mls-toggle-grid">';
        echo '<label class="mls-toggle-row mls-toggle-row--card"><input type="checkbox" name="request_shield_route_front" value="1" ' . checked(!empty($s['request_shield_route_front']), true, false) . '><span>Front-end dinâmico</span></label>';
        echo '<label class="mls-toggle-row mls-toggle-row--card"><input type="checkbox" name="request_shield_route_login" value="1" ' . checked(!empty($s['request_shield_route_login']), true, false) . '><span>wp-login.php</span></label>';
        echo '<label class="mls-toggle-row mls-toggle-row--card"><input type="checkbox" name="request_shield_route_xmlrpc" value="1" ' . checked(!empty($s['request_shield_route_xmlrpc']), true, false) . '><span>xmlrpc.php</span></label>';
        echo '<label class="mls-toggle-row mls-toggle-row--card"><input type="checkbox" name="request_shield_route_ajax" value="1" ' . checked(!empty($s['request_shield_route_ajax']), true, false) . '><span>admin-ajax.php</span></label>';
        echo '<label class="mls-toggle-row mls-toggle-row--card"><input type="checkbox" name="request_shield_route_cron" value="1" ' . checked(!empty($s['request_shield_route_cron']), true, false) . '><span>wp-cron.php</span></label>';
        echo '</div></div>';
        echo '<div class="mls-panel mls-panel--inner"><h3 class="mls-subtitle">Padrões configuráveis</h3><div class="mls-field"><label>User-Agent patterns</label><textarea name="request_shield_ua_patterns" rows="8">' . esc_textarea(implode("\n", (array) ($s['request_shield_ua_patterns'] ?? []))) . '</textarea></div><div class="mls-field"><label>Query patterns</label><textarea name="request_shield_query_patterns" rows="8">' . esc_textarea(implode("\n", (array) ($s['request_shield_query_patterns'] ?? []))) . '</textarea></div><p><small>O bloqueio de probes PHP maliciosos já vem embutido, ativo por padrão e não depende de User-Agent.</small></p></div>';
        echo '</div><p><button class="mls-action-button" type="submit" name="mls_save" value="1">Salvar Configurações</button></p></form>';

        $shield_rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}" . MLS_LOG_TABLE . " WHERE event_type IN ('request_shield_log','request_shield_block') ORDER BY id DESC LIMIT 50");
        echo '<div class="mls-panel"><div class="mls-panel-head"><h2>Últimos eventos do Request Shield</h2></div><table class="widefat striped mls-table"><thead><tr><th>Data</th><th>IP</th><th>Status</th><th>Rota</th><th>Detalhes</th><th>User-Agent</th></tr></thead><tbody>';
        if ($shield_rows) {
            foreach ($shield_rows as $row) {
                echo '<tr><td>' . esc_html($row->created_at) . '</td><td>' . esc_html($row->ip) . '</td><td>' . esc_html($row->status) . '</td><td>' . esc_html($row->route) . '</td><td>' . esc_html($row->details) . '</td><td>' . esc_html($row->user_agent) . '</td></tr>';
            }
        } else {
            echo '<tr><td colspan="6">Nenhum evento do Request Shield ainda.</td></tr>';
        }
        echo '</tbody></table></div>';

    // ── Whitelist tab ──
    } elseif ($tab === 'whitelist') {
        echo '<form method="post" class="mls-panel">';
        wp_nonce_field('mls_save_settings');
        if (empty($s['login_emergency_token'])) {
            $s['login_emergency_token'] = mls_generate_emergency_token();
            update_option(MLS_OPTION_KEY, $s, false);
            mls_write_login_token_export($s);
        }
        echo '<h2>Whitelist</h2><div class="mls-grid-2"><div class="mls-field"><label>Whitelist de IPs</label><textarea name="whitelist_ips" rows="10">' . esc_textarea(implode("\n", $s['whitelist_ips'])) . '</textarea></div><div class="mls-panel"><h2>Ferramentas rápidas</h2><div class="mls-mini-list"><div><strong>IP atual detectado:</strong> ' . esc_html(mls_ip()) . '</div><div><strong>Na whitelist:</strong> ' . (mls_is_whitelisted(mls_ip()) ? 'Sim' : 'Não') . '</div><div><strong>Total na whitelist:</strong> ' . count((array) $s['whitelist_ips']) . '</div><div><strong>Token emergencial:</strong> <code>' . esc_html($s['login_emergency_token']) . '</code></div></div><div class="mls-field"><label>Duração do acesso emergencial (minutos)</label><input type="number" min="5" name="login_emergency_duration_minutes" value="' . (int) ($s['login_emergency_duration_minutes'] ?? 60) . '"><small>Quando o token for usado no wp-login.php, o IP atual entra na allowlist temporária pelo tempo definido.</small></div><div class="mls-actions-row"><button class="mls-action-button mls-action-button--secondary" type="submit" name="mls_add_current_ip" value="1">Adicionar meu IP atual</button><button class="mls-action-button mls-action-button--secondary" type="submit" name="mls_regenerate_emergency_token" value="1">Regenerar token</button><button class="mls-action-button" type="submit" name="mls_save" value="1">Salvar Configurações</button></div><p><small>Uso emergencial: acesse <code>wp-login.php?mls_token=SEU_TOKEN</code>. Se o token for válido, o IP atual entra na allowlist temporária.</small></p></div></div></form>';

    // ── Lockouts tab ──
    } elseif ($tab === 'lockouts') {
        $where = " WHERE is_active=1 AND expires_at>'" . mls_now() . "'";
        if ($lock_ip_filter !== '') { $where .= $wpdb->prepare(" AND ip LIKE %s", '%' . $wpdb->esc_like($lock_ip_filter) . '%'); }
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}" . MLS_LOCK_TABLE . $where . " ORDER BY id DESC");
        $remaining = mls_emergency_remaining();
        $manual_blocks = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}" . MLS_MANUAL_BLOCK_TABLE . " ORDER BY created_at DESC");

        echo '<div class="mls-grid-2"><div class="mls-panel"><div class="mls-panel-head"><h2>Bloqueios ativos</h2><a class="mls-action-button mls-action-button--secondary" href="?page=mls-dashboard&tab=lockouts&unlock_all=1">Desbloquear Todos</a></div><form method="get" class="mls-log-filters"><input type="hidden" name="page" value="mls-dashboard"><input type="hidden" name="tab" value="lockouts"><div class="mls-field"><label>Filtrar por IP</label><input type="text" name="lock_ip_filter" value="' . esc_attr($lock_ip_filter) . '" placeholder="Digite parte do IP"></div><div class="mls-field mls-field--actions"><button class="mls-action-button" type="submit">Filtrar</button></div></form><table class="widefat striped mls-table"><thead><tr><th>IP</th><th>Status</th><th>Risco</th><th>Expira</th><th>Tempo restante</th><th>Ação</th></tr></thead><tbody>';

        if ($rows) {
            foreach ($rows as $r) {
                $remaining_lock = mls_format_seconds_remaining(mls_seconds_remaining_from_datetime($r->expires_at));
                $score = mls_calculate_risk_score($r->ip);
                echo '<tr><td>' . esc_html($r->ip) . '<br><small>' . esc_html(mls_guess_source($r->ip)) . ' / ' . esc_html(mls_guess_ip_type($r->ip)) . '</small></td><td><span class="mls-badge mls-badge--danger">Bloqueado</span></td><td>' . (int)$score . '<br><small>' . esc_html(mls_risk_label($score)) . '</small></td><td>' . esc_html($r->expires_at) . '</td><td>' . esc_html($remaining_lock) . '</td><td><a class="mls-action-button mls-action-button--secondary" href="?page=mls-dashboard&tab=lockouts&unlock_ip=' . urlencode($r->ip) . '">Desbloquear</a></td></tr>';
            }
        } else {
            echo '<tr><td colspan="6">Nenhum bloqueio ativo.</td></tr>';
        }
        echo '</tbody></table></div><div class="mls-panel"><h2>Blacklist manual e emergência</h2><form method="post" class="mls-mini-form">';
        wp_nonce_field('mls_save_settings');
        echo '<div class="mls-field"><label>Bloquear IP manualmente</label><input type="text" name="manual_block_ip" placeholder="Ex: 192.168.0.10"></div><p><button class="mls-action-button" type="submit" name="mls_manual_block_ip" value="1">Bloquear IP</button></p></form><div class="mls-mini-list"><div><strong>Emergência:</strong> ' . (mls_emergency_active() ? 'Ativa' : 'Inativa') . '</div><div><strong>Tempo restante:</strong> ' . ($remaining ? gmdate('i\\m s\\s', $remaining) : '0m 00s') . '</div></div><div class="mls-actions-row"><form method="post">';
        wp_nonce_field('mls_save_settings');
        echo '<button class="mls-action-button" type="submit" name="mls_emergency_open" value="1">Liberar Emergência 15m</button> <button class="mls-action-button mls-action-button--secondary" type="submit" name="mls_emergency_close" value="1">Encerrar Emergência</button></form></div><h3 class="mls-subtitle">IPs bloqueados manualmente</h3><table class="widefat striped mls-table"><thead><tr><th>IP</th><th>Tipo</th><th>Risco</th><th>Criado em</th><th>Ação</th></tr></thead><tbody>';

        if ($manual_blocks) {
            foreach ($manual_blocks as $mb) {
                $score = mls_calculate_risk_score($mb->ip);
                echo '<tr><td>' . esc_html($mb->ip) . '</td><td>' . esc_html(mls_guess_source($mb->ip)) . ' / ' . esc_html(mls_guess_ip_type($mb->ip)) . '</td><td>' . (int)$score . '<br><small>' . esc_html(mls_risk_label($score)) . '</small></td><td>' . esc_html($mb->created_at) . '</td><td><a class="mls-action-button mls-action-button--secondary" href="?page=mls-dashboard&tab=lockouts&unblock_manual_ip=' . urlencode($mb->ip) . '">Remover</a></td></tr>';
            }
        } else {
            echo '<tr><td colspan="5">Nenhum IP na blacklist manual.</td></tr>';
        }
        echo '</tbody></table></div></div>';

    // ── License tab ──
    } elseif ($tab === 'license') {
        MLS_License::render_tab();

    // ── Logs tab ──
    } else {
        $where = [];
        if ($log_route !== '') $where[] = $wpdb->prepare("route = %s", $log_route);
        if ($log_status !== '') $where[] = $wpdb->prepare("status = %s", $log_status);
        if ($log_event !== '') $where[] = $wpdb->prepare("event_type = %s", $log_event);
        if ($log_search !== '') {
            $like = '%' . $wpdb->esc_like($log_search) . '%';
            $where[] = $wpdb->prepare("(ip LIKE %s OR username LIKE %s OR details LIKE %s OR user_agent LIKE %s)", $like, $like, $like, $like);
        }
        $sql = "SELECT * FROM {$wpdb->prefix}" . MLS_LOG_TABLE;
        if ($where) $sql .= " WHERE " . implode(" AND ", $where);
        $sql .= " ORDER BY id DESC LIMIT 100";
        $rows = $wpdb->get_results($sql);

        echo '<div class="mls-panel"><div class="mls-panel-head"><h2>Logs recentes</h2><div class="mls-actions-row"><a class="mls-action-button mls-action-button--secondary" href="?page=mls-dashboard&tab=logs&mls_export_logs=1">Exportar CSV</a><form method="post">';
        wp_nonce_field('mls_save_settings');
        echo '<button class="mls-action-button mls-action-button--secondary" type="submit" name="mls_clear_logs" value="1">Limpar Logs</button></form></div></div><form method="get" class="mls-log-filters"><input type="hidden" name="page" value="mls-dashboard"><input type="hidden" name="tab" value="logs"><div class="mls-field"><label>Rota</label><select name="log_route"><option value="">Todas</option><option value="wp-login.php" ' . selected($log_route, 'wp-login.php', false) . '>wp-login.php</option><option value="xmlrpc.php" ' . selected($log_route, 'xmlrpc.php', false) . '>xmlrpc.php</option><option value="front-end" ' . selected($log_route, 'front-end', false) . '>front-end</option><option value="admin-ajax.php" ' . selected($log_route, 'admin-ajax.php', false) . '>admin-ajax.php</option><option value="wp-cron.php" ' . selected($log_route, 'wp-cron.php', false) . '>wp-cron.php</option></select></div><div class="mls-field"><label>Status</label><select name="log_status"><option value="">Todos</option><option value="failed" ' . selected($log_status, 'failed', false) . '>failed</option><option value="blocked" ' . selected($log_status, 'blocked', false) . '>blocked</option><option value="warning" ' . selected($log_status, 'warning', false) . '>warning</option></select></div><div class="mls-field"><label>Evento</label><select name="log_event"><option value="">Todos</option><option value="login_failure" ' . selected($log_event, 'login_failure', false) . '>login_failure</option><option value="lockout_created" ' . selected($log_event, 'lockout_created', false) . '>lockout_created</option><option value="xmlrpc_request" ' . selected($log_event, 'xmlrpc_request', false) . '>xmlrpc_request</option><option value="xmlrpc_blocked" ' . selected($log_event, 'xmlrpc_blocked', false) . '>xmlrpc_blocked</option><option value="auto_manual_block" ' . selected($log_event, 'auto_manual_block', false) . '>auto_manual_block</option><option value="request_shield_log" ' . selected($log_event, 'request_shield_log', false) . '>request_shield_log</option><option value="request_shield_block" ' . selected($log_event, 'request_shield_block', false) . '>request_shield_block</option></select></div><div class="mls-field"><label>Buscar</label><input type="text" name="log_search" value="' . esc_attr($log_search) . '" placeholder="IP, user-agent, usuário ou detalhe"></div><div class="mls-field mls-field--actions"><button class="mls-action-button" type="submit">Filtrar</button></div></form><table class="widefat striped mls-table"><thead><tr><th>Data</th><th>IP</th><th>Risco</th><th>Origem</th><th>Evento</th><th>Status</th><th>User-Agent</th><th>Ações rápidas</th></tr></thead><tbody>';

        if ($rows) {
            foreach ($rows as $r) {
                $score = mls_calculate_risk_score($r->ip);
                echo '<tr><td>' . esc_html($r->created_at) . '</td><td>' . esc_html($r->ip) . '</td><td>' . (int)$score . '<br><small>' . esc_html(mls_risk_label($score)) . '</small></td><td>' . esc_html(mls_guess_source($r->ip)) . ' / ' . esc_html(mls_guess_ip_type($r->ip)) . '</td><td>' . esc_html($r->event_type) . '<br><small>' . esc_html($r->route) . ' / ' . esc_html($r->details) . '</small></td><td>' . esc_html($r->status) . '</td><td>' . esc_html($r->user_agent) . '</td><td>' . mls_row_action_buttons_from_ip($r->ip, 'logs') . '</td></tr>';
            }
        } else {
            echo '<tr><td colspan="8">Nenhum log encontrado.</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    echo '</div>';
}

// Licença pelo site tools.mlopesdesign.com.br (ML License Hub). Só carrega no painel e no
// WP-Cron: nunca na tela de login. Sem licença a proteção continua igual (ver a classe).
require_once __DIR__ . '/includes/class-mls-license.php';
MLS_License::boot();

// Atualizacao automatica via GitHub Releases (repositorio publico ml-login-secury-releases).
require_once __DIR__ . '/includes/class-mls-updater.php';
add_action(
	'plugins_loaded',
	static function () {
		MLS_GitHub_Updater::boot( __FILE__, MLS_VERSION );
	},
	5
);
