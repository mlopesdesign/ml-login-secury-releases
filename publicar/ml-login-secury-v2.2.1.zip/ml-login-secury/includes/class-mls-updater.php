<?php
/**
 * Atualizacao automatica via GitHub Releases (padrao ML Lopes Design).
 *
 * Fonte: repositorio PUBLICO mlopesdesign/ml-login-secury-releases (somente ZIPs).
 * - Usa somente o asset exato ml-login-secury-vX.Y.Z.zip (sem zipball, sem "qualquer ZIP").
 * - response quando ha versao nova; no_update caso contrario (controle de auto-update do WP).
 * - Cache: 6 h com sucesso, 15 min em falha ou sem o ZIP exato.
 * - Registra no painel, no WP-Cron (atualizacao automatica) e no WP-CLI.
 * - Sem rotina pos-instalacao: o ZIP oficial ja vem com a pasta ml-login-secury/.
 *
 * @package ml-login-secury
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'MLS_GitHub_Updater' ) ) {

	final class MLS_GitHub_Updater {

		const USER      = 'mlopesdesign';
		const REPO      = 'ml-login-secury-releases';
		const SLUG      = 'ml-login-secury';
		const CACHE_KEY = 'mls_gh_release';
		const OK_TTL    = 21600;
		const FAIL_TTL  = 900;

		/** @var MLS_GitHub_Updater|null */
		private static $instance = null;

		/** @var string */
		private $basename;

		/** @var string */
		private $version;

		/** @var string */
		private $url;

		/**
		 * @param string $main_file Arquivo principal do plugin (__FILE__).
		 * @param string $version   Versao instalada.
		 */
		public static function boot( $main_file, $version ) {
			$is_cli = defined( 'WP_CLI' ) && WP_CLI;
			if ( null !== self::$instance || ( ! is_admin() && ! wp_doing_cron() && ! $is_cli ) ) {
				return;
			}
			self::$instance = new self( $main_file, $version );
		}

		private function __construct( $main_file, $version ) {
			$this->basename = plugin_basename( $main_file );
			$this->version  = (string) $version;
			$this->url      = plugin_dir_url( $main_file );
			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_update' ) );
			add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
			add_action( 'upgrader_process_complete', array( $this, 'after_upgrade' ), 10, 2 );
		}

		/**
		 * @return array|null
		 */
		private function get_release() {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
			if ( 'error' === $cached ) {
				return null;
			}

			$response = wp_remote_get(
				sprintf( 'https://api.github.com/repos/%s/%s/releases/latest', self::USER, self::REPO ),
				array(
					'timeout' => 10,
					'headers' => array(
						'Accept'     => 'application/vnd.github+json',
						'User-Agent' => self::SLUG . '-updater/' . $this->version,
					),
				)
			);

			$data = null;
			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			}
			if ( ! is_array( $data ) || empty( $data['tag_name'] ) ) {
				set_site_transient( self::CACHE_KEY, 'error', self::FAIL_TTL );
				return null;
			}
			set_site_transient( self::CACHE_KEY, $data, '' !== $this->package_url( $data ) ? self::OK_TTL : self::FAIL_TTL );
			return $data;
		}

		/**
		 * @param array $release
		 * @return string
		 */
		private function release_version( $release ) {
			return ltrim( (string) ( isset( $release['tag_name'] ) ? $release['tag_name'] : '' ), 'vV' );
		}

		/**
		 * @param array $release
		 * @return string
		 */
		private function package_url( $release ) {
			$expected = self::SLUG . '-v' . $this->release_version( $release ) . '.zip';
			$assets   = isset( $release['assets'] ) ? (array) $release['assets'] : array();
			foreach ( $assets as $asset ) {
				if ( is_array( $asset ) && isset( $asset['name'], $asset['browser_download_url'] ) && $asset['name'] === $expected ) {
					return (string) $asset['browser_download_url'];
				}
			}
			return '';
		}

		/**
		 * @return array
		 */
		private function icons() {
			return array(
				'1x'      => $this->url . 'assets/images/icon-128x128.png',
				'2x'      => $this->url . 'assets/images/icon-256x256.png',
				'default' => $this->url . 'assets/images/icon-256x256.png',
			);
		}

		/**
		 * @param mixed $transient
		 * @return mixed
		 */
		public function check_update( $transient ) {
			if ( ! is_object( $transient ) || empty( $transient->checked ) ) {
				return $transient;
			}
			$release = $this->get_release();
			$remote  = $release ? $this->release_version( $release ) : '';
			$package = $release ? $this->package_url( $release ) : '';

			$item = (object) array(
				'id'            => 'github.com/' . self::USER . '/' . self::REPO,
				'slug'          => self::SLUG,
				'plugin'        => $this->basename,
				'new_version'   => $remote,
				'url'           => 'https://github.com/' . self::USER . '/' . self::REPO,
				'package'       => $package,
				'icons'         => $this->icons(),
				'banners'       => array(),
				'banners_rtl'   => array(),
				'tested'        => '6.8',
				'requires'      => '6.0',
				'requires_php'  => '7.4',
				'compatibility' => new stdClass(),
			);

			if ( '' !== $remote && '' !== $package && version_compare( $this->version, $remote, '<' ) ) {
				if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
					$transient->response = array();
				}
				$transient->response[ $this->basename ] = $item;
				if ( isset( $transient->no_update ) && is_array( $transient->no_update ) ) {
					unset( $transient->no_update[ $this->basename ] );
				}
			} else {
				$item->new_version = $this->version;
				$item->package     = '';
				if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
					$transient->no_update = array();
				}
				$transient->no_update[ $this->basename ] = $item;
				if ( isset( $transient->response ) && is_array( $transient->response ) ) {
					unset( $transient->response[ $this->basename ] );
				}
			}
			return $transient;
		}

		/**
		 * @param mixed  $result
		 * @param string $action
		 * @param mixed  $args
		 * @return mixed
		 */
		public function plugin_info( $result, $action, $args ) {
			if ( 'plugin_information' !== $action || ! is_object( $args ) || ! isset( $args->slug ) || self::SLUG !== $args->slug ) {
				return $result;
			}
			$release = $this->get_release();
			if ( ! $release || '' === $this->package_url( $release ) ) {
				return $result;
			}
			return (object) array(
				'name'          => 'ML Login Secury',
				'slug'          => self::SLUG,
				'version'       => $this->release_version( $release ),
				'author'        => '<a href="https://mlopesdesign.com.br">ML Lopes Design</a>',
				'homepage'      => 'https://mlopesdesign.com.br',
				'requires'      => '6.0',
				'tested'        => '6.8',
				'requires_php'  => '7.4',
				'last_updated'  => (string) ( isset( $release['published_at'] ) ? $release['published_at'] : '' ),
				'download_link' => $this->package_url( $release ),
				'icons'         => $this->icons(),
				'banners'       => array(),
				'sections'      => array(
					'changelog' => nl2br( esc_html( (string) ( isset( $release['body'] ) ? $release['body'] : '' ) ) ),
				),
			);
		}

		/**
		 * @param mixed $upgrader
		 * @param mixed $hook_extra
		 */
		public function after_upgrade( $upgrader, $hook_extra ) {
			if ( ! is_array( $hook_extra ) || ! isset( $hook_extra['type'] ) || 'plugin' !== $hook_extra['type'] ) {
				return;
			}
			$plugins = isset( $hook_extra['plugins'] ) ? (array) $hook_extra['plugins'] : array();
			$single  = isset( $hook_extra['plugin'] ) ? $hook_extra['plugin'] : '';
			if ( in_array( $this->basename, $plugins, true ) || $single === $this->basename ) {
				delete_site_transient( self::CACHE_KEY );
			}
		}
	}
}
