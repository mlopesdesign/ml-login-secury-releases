<?php
/**
 * Licença do ML Login Secury (2.2.0).
 *
 * A licença é emitida e conferida pelo site tools.mlopesdesign.com.br (ML License Hub,
 * cliente ML_License_Client_V2). Aceita a chave do próprio plugin ou a do Pacote Agência.
 *
 * Regras (plugin de SEGURANÇA):
 * - Sem teste/licença válidos a proteção do site continua EXATAMENTE igual: bloqueio
 *   antecipado (mu-plugin), Request Shield, limite de tentativas, XML-RPC, whitelist,
 *   token de emergência. Nada é desligado e nenhum dado é apagado.
 * - Só a gravação de configurações no painel do plugin trava. As ações que apenas
 *   liberam acesso (desbloquear IP, emergência, adicionar o meu IP) continuam
 *   disponíveis para o administrador nunca ficar trancado para fora.
 * - A licença só é carregada no painel (is_admin) e no WP-Cron. Nunca roda na tela de
 *   login, no front-end ou no XML-RPC, e a conferência de rede acontece só no cron
 *   diário, no auto-teste da 1ª visita ao painel e nos botões da aba Licença.
 *
 * @package ml-login-secury
 */

defined( 'ABSPATH' ) || exit;

// 2.2.1: o cliente carrega SEMPRE primeiro. Na 2.2.0 havia um "if ( class_exists( 'MLS_License' ) ) return;"
// antes desta linha: o PHP declara a classe (sem herança) já na compilação do arquivo, então a checagem
// dava verdadeiro na 1ª carga, o arquivo voltava cedo e ML_License_Client_V2 não existia (erro fatal no painel).
require_once __DIR__ . '/class-ml-license-client.php';

if ( ! class_exists( 'MLS_License' ) ) :

final class MLS_License {

	const API_BASE    = 'https://tools.mlopesdesign.com.br/wp-json/mllh/v1';
	const PUBLIC_KEY  = 'VGZQp2X3RJMuDmQBlIEXS4fqsZD1CnFlIJgfVtY/pHo=';
	const PRODUCT_ID  = 'ml-login-secury';
	const BUY_URL     = 'https://tools.mlopesdesign.com.br/precos/';
	const ACCOUNT_URL = 'https://tools.mlopesdesign.com.br/minha-conta/';
	const AUTO_TRIAL  = 'mls_auto_trial_tried';

	/** @var ML_License_Client_V2|null */
	private static $client = null;

	/** @var bool|null */
	private static $locked = null;

	/** @var bool */
	private static $booted = false;

	/**
	 * Liga a licença só no painel e no WP-Cron (nunca em wp-login.php / front-end).
	 */
	public static function boot() {
		if ( self::$booted || ( ! is_admin() && ! wp_doing_cron() ) ) {
			return;
		}
		self::$booted = true;
		self::client(); // registra e agenda a renovação diária (cron).
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_init', array( __CLASS__, 'maybe_auto_trial' ), 5 );
		add_action( 'admin_post_mls_activate_license', array( __CLASS__, 'handle_activate' ) );
		add_action( 'admin_post_mls_sync_license', array( __CLASS__, 'handle_sync' ) );
		add_action( 'admin_post_mls_remove_license', array( __CLASS__, 'handle_remove' ) );
		$opt = self::client()->option_name();
		foreach ( array( 'added_option', 'updated_option', 'deleted_option' ) as $hook ) {
			add_action(
				$hook,
				static function ( $name ) use ( $opt ) {
					if ( $name === $opt ) {
						MLS_License::forget();
					}
				}
			);
		}
	}

	public static function client() {
		if ( null === self::$client ) {
			self::$client = new ML_License_Client_V2(
				array(
					'api_base'   => self::API_BASE,
					'product'    => self::PRODUCT_ID,
					'public_key' => self::PUBLIC_KEY,
					'version'    => MLS_VERSION,
				)
			);
		}
		return self::$client;
	}

	/** Teste ou licença válidos neste site (leitura local, sem rede). */
	public static function is_active() {
		return self::client()->is_premium();
	}

	/** Painel travado para gravar configurações (sem teste nem licença). */
	public static function is_locked() {
		if ( null === self::$locked ) {
			self::$locked = ! self::is_active();
		}
		return self::$locked;
	}

	public static function forget() {
		self::$locked = null;
	}

	/** 1ª visita ao painel: começa o teste grátis sozinho (uma tentativa por site). */
	public static function maybe_auto_trial() {
		if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) || get_option( self::AUTO_TRIAL ) ) {
			return;
		}
		update_option( self::AUTO_TRIAL, time(), false );
		$state = self::client()->state();
		if ( empty( $state['active'] ) && 'none' === $state['mode'] && empty( $state['trial_used'] ) ) {
			self::client()->start_trial();
		}
	}

	/**
	 * Ações de gravação do painel que travam sem licença (configurações).
	 * As ações que só liberam acesso ficam de fora de propósito (ver cabeçalho).
	 */
	public static function locked_write_keys() {
		return array(
			'post' => array( 'mls_save', 'mls_import_settings', 'mls_manual_block_ip', 'mls_clear_logs', 'mls_regenerate_emergency_token' ),
			'get'  => array( 'mls_quick_whitelist_ip', 'mls_quick_block_ip' ),
		);
	}

	/**
	 * Chamado no início do painel. Sem licença, descarta as ações de gravação de
	 * configurações desta requisição (nada é processado) e devolve true.
	 */
	public static function filter_admin_request() {
		if ( ! self::is_locked() ) {
			return false;
		}
		$keys    = self::locked_write_keys();
		$blocked = false;
		foreach ( $keys['post'] as $k ) {
			if ( isset( $_POST[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				unset( $_POST[ $k ], $_REQUEST[ $k ] );
				$blocked = true;
			}
		}
		foreach ( $keys['get'] as $k ) {
			if ( isset( $_GET[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				unset( $_GET[ $k ], $_REQUEST[ $k ] );
				$blocked = true;
			}
		}
		return $blocked;
	}

	public static function locked_message() {
		return 'Sem licença ativa: as configurações não foram salvas. A proteção do site continua funcionando normalmente.';
	}

	/** Aviso discreto nas abas do plugin (exceto na aba Licença). */
	public static function render_locked_notice() {
		if ( ! self::is_locked() ) {
			return;
		}
		echo '<div class="mls-panel mls-license-alert"><strong>Sem licença ativa.</strong> A proteção do login e do site continua funcionando normalmente; só a gravação de configurações deste painel está bloqueada. <a href="' . esc_url( admin_url( 'admin.php?page=mls-dashboard&tab=license' ) ) . '">Ativar licença ou começar o teste grátis</a></div>';
	}

	/* ------------------------------------------------------------------ tela */

	public static function summary() {
		$state  = self::client()->state();
		$active = ! empty( $state['active'] );
		$mode   = (string) ( $state['mode'] ?? 'none' );
		$plan   = strtolower( (string) ( $state['plan'] ?? '' ) );
		$days   = $state['days_left'] ?? null;

		$plans      = array(
			'trial'    => 'Teste grátis',
			'monthly'  => 'Mensal',
			'annual'   => 'Anual',
			'yearly'   => 'Anual',
			'lifetime' => 'Vitalícia',
			'manual'   => 'Cortesia',
			'courtesy' => 'Cortesia',
		);
		$plan_label = $plans[ $plan ] ?? ( '' !== $plan ? ucfirst( $plan ) : '—' );

		if ( $active && 'trial' === $mode ) {
			$label   = 'Teste';
			$accent  = 'blue';
			$message = null === $days ? 'Teste grátis ativo neste site.' : sprintf( 1 === (int) $days ? 'Teste grátis ativo: falta %d dia.' : 'Teste grátis ativo: faltam %d dias.', (int) $days );
		} elseif ( $active ) {
			$label   = 'Ativa';
			$accent  = 'green';
			$message = 'Licença ativa neste site.';
		} else {
			$label  = 'Sem licença';
			$accent = 'red';
			if ( 'trial_expired' === ( $state['status'] ?? '' ) ) {
				$message = 'O teste grátis terminou. Ative uma licença para voltar a alterar as configurações. A proteção do site continua funcionando normalmente.';
			} elseif ( '' !== (string) ( $state['message'] ?? '' ) ) {
				$message = (string) $state['message'];
			} else {
				$message = 'Comece o teste grátis de 30 dias ou ative a sua licença.';
			}
		}

		$expires_label = '';
		if ( ! empty( $state['expires_at'] ) ) {
			$ts = strtotime( (string) $state['expires_at'] );
			if ( $ts ) {
				$expires_label = wp_date( get_option( 'date_format', 'd/m/Y' ), $ts );
			}
		}

		return array(
			'active'          => $active,
			'mode'            => $mode,
			'is_trial'        => $active && 'trial' === $mode,
			'label'           => $label,
			'accent'          => $accent,
			'message'         => $message,
			'plan'            => $plan,
			'plan_label'      => $plan_label,
			'expires_label'   => $expires_label,
			'days_left'       => $days,
			'key_masked'      => (string) ( $state['key_masked'] ?? '' ),
			'can_start_trial' => ! $active && empty( $state['trial_used'] ) && 'license' !== $mode,
			'domain'          => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
		);
	}

	public static function render_tab() {
		$l    = self::summary();
		$post = esc_url( admin_url( 'admin-post.php' ) );

		if ( $l['active'] && 'lifetime' !== $l['plan'] && $l['expires_label'] ) {
			$valid = $l['expires_label'];
		} else {
			$valid = $l['active'] ? 'Sem vencimento' : '—';
		}
		$days = ( $l['active'] && null !== $l['days_left'] && $l['expires_label'] ) ? (string) (int) $l['days_left'] : '—';

		echo '<div class="mls-stats">';
		mls_card( 'Situação', esc_html( $l['label'] ), $l['accent'] );
		mls_card( 'Plano', esc_html( $l['plan_label'] ), 'blue' );
		mls_card( 'Válida até', esc_html( $valid ), 'dark' );
		mls_card( 'Dias restantes', esc_html( $days ), 'green' );
		echo '</div>';

		echo '<div class="mls-grid-2">';

		// Licença.
		echo '<div class="mls-panel"><div class="mls-panel-head"><h2>Licença</h2><span class="mls-shell__tag">' . esc_html( $l['domain'] ) . '</span></div>';
		echo '<p class="mls-license-copy">' . esc_html( $l['message'] ) . '</p>';

		if ( 'license' === $l['mode'] && '' !== $l['key_masked'] ) {
			echo '<div class="mls-mini-list"><div><strong>Chave neste site:</strong> <code>' . esc_html( $l['key_masked'] ) . '</code></div></div>';
			echo '<div class="mls-actions-row">';
			echo '<form method="post" action="' . $post . '">';
			wp_nonce_field( 'mls_sync_license' );
			echo '<input type="hidden" name="action" value="mls_sync_license"><input type="hidden" name="mls_op" value="check"><button type="submit" class="mls-action-button">Conferir agora</button></form>';
			echo '<form method="post" action="' . $post . '">';
			wp_nonce_field( 'mls_remove_license' );
			echo '<input type="hidden" name="action" value="mls_remove_license"><button type="submit" class="mls-action-button mls-action-button--secondary">Remover deste site</button></form>';
			echo '</div>';
		} else {
			echo '<form method="post" action="' . $post . '">';
			wp_nonce_field( 'mls_activate_license' );
			echo '<input type="hidden" name="action" value="mls_activate_license">';
			echo '<div class="mls-field"><label for="mls-license-key">Chave da licença</label><input type="text" id="mls-license-key" name="license_key" value="" placeholder="Cole aqui a sua chave" autocomplete="off" spellcheck="false"></div>';
			echo '<div class="mls-actions-row"><button type="submit" class="mls-action-button">Ativar licença</button></div></form>';
			echo '<div class="mls-actions-row">';
			if ( $l['can_start_trial'] ) {
				echo '<form method="post" action="' . $post . '">';
				wp_nonce_field( 'mls_sync_license' );
				echo '<input type="hidden" name="action" value="mls_sync_license"><input type="hidden" name="mls_op" value="trial"><button type="submit" class="mls-action-button mls-action-button--secondary">Começar teste grátis de 30 dias</button></form>';
			} elseif ( $l['is_trial'] ) {
				echo '<form method="post" action="' . $post . '">';
				wp_nonce_field( 'mls_sync_license' );
				echo '<input type="hidden" name="action" value="mls_sync_license"><input type="hidden" name="mls_op" value="check"><button type="submit" class="mls-action-button mls-action-button--secondary">Conferir agora</button></form>';
			}
			echo '</div>';
		}
		echo '<div class="mls-actions-row"><a class="mls-action-button mls-action-button--secondary" href="' . esc_url( self::BUY_URL ) . '" target="_blank" rel="noopener">Comprar licença</a><a class="mls-action-button mls-action-button--secondary" href="' . esc_url( self::ACCOUNT_URL ) . '" target="_blank" rel="noopener">Minha conta</a></div>';
		echo '</div>';

		// Como funciona.
		echo '<div class="mls-panel"><div class="mls-panel-head"><h2>Como funciona</h2><span class="mls-shell__tag">tools.mlopesdesign.com.br</span></div>';
		echo '<table class="widefat striped mls-table"><tbody>';
		echo '<tr><td><strong>Teste grátis</strong></td><td>30 dias com tudo liberado, uma vez por site. Reinstalar não reinicia.</td></tr>';
		echo '<tr><td><strong>Licença anual</strong></td><td>Vale em 1 site. Para usar em outro, remova deste site.</td></tr>';
		echo '<tr><td><strong>Pacote Agência</strong></td><td>Uma chave para todos os plugins ML em 5, 10 ou 50 sites.</td></tr>';
		echo '<tr><td><strong>Sem licença</strong></td><td>A proteção do login e do site continua funcionando igual. Só fica bloqueado salvar configurações neste painel. Desbloquear IPs e a liberação de emergência continuam disponíveis.</td></tr>';
		echo '</tbody></table>';
		echo '<p><small>A licença é conferida uma vez por dia, nunca na tela de login. Sem internet, o painel continua liberado por até 7 dias.</small></p>';
		echo '</div>';

		echo '</div>';
	}

	/* ------------------------------------------------------------------ ações */

	public static function handle_activate() {
		self::guard_request( 'mls_activate_license' );
		$key    = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$result = self::client()->activate( $key );
		if ( is_wp_error( $result ) ) {
			self::redirect( 'error', $result->get_error_message() );
		}
		self::redirect( 'success', 'Licença ativada neste site.' );
	}

	/** Começa o teste grátis ou confere a licença agora. */
	public static function handle_sync() {
		self::guard_request( 'mls_sync_license' );
		$op     = isset( $_POST['mls_op'] ) ? sanitize_key( wp_unslash( $_POST['mls_op'] ) ) : 'check';
		$result = 'trial' === $op ? self::client()->start_trial() : self::client()->refresh();
		if ( is_wp_error( $result ) ) {
			self::redirect( 'error', $result->get_error_message() );
		}
		self::redirect( 'success', 'trial' === $op ? 'Teste grátis de 30 dias ativo neste site.' : 'Licença conferida.' );
	}

	public static function handle_remove() {
		self::guard_request( 'mls_remove_license' );
		self::client()->deactivate();
		self::redirect( 'success', 'Licença removida deste site. A chave pode ser usada em outro site.' );
	}

	private static function guard_request( $nonce_action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permissão insuficiente.', 'ml-login-secury' ) );
		}
		check_admin_referer( $nonce_action );
	}

	private static function redirect( $type, $message ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'            => 'mls-dashboard',
					'tab'             => 'license',
					'mls_notice_type' => 'error' === $type ? 'error' : 'success',
					'mls_notice'      => rawurlencode( $message ),
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}

endif;
