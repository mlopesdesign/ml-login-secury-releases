<?php
/**
 * Desinstalação do ML Login Secury.
 *
 * 2.2.0: a licença local fica no banco (reinstalar recupera); só a renovação diária
 * da licença é desagendada. Configurações, logs e bloqueios não são apagados aqui.
 *
 * @package ml-login-secury
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

wp_clear_scheduled_hook( 'mllc_ml_login_secury_refresh' );
