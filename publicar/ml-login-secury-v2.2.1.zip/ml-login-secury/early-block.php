<?php
// ML Login Secury — MU early block v2.1.0
// Pure PHP, no WordPress functions.
// Covers: /wp-login.php (all modes) + unauthenticated /wp-admin/* (standard + whitelist modes).

if (!isset($_SERVER['REQUEST_URI'])) {
    return;
}

$mls_uri  = (string) $_SERVER['REQUEST_URI'];
$mls_path = strtolower((string) parse_url($mls_uri, PHP_URL_PATH));
if ($mls_path === '') {
    $mls_path = strtolower($mls_uri);
}

$mls_ip  = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
$mls_now = time();
$mls_uploads_dir = dirname(dirname(__DIR__)) . '/uploads/ml-login-secury';

// ─── Detecção de rotas relevantes ────────────────────────────────────────────
$mls_is_login_path  = strpos($mls_path, '/wp-login.php') !== false;
$mls_is_admin_path  = (strpos($mls_path, '/wp-admin/') === 0) && !$mls_is_login_path;
// Rotas wp-admin legítimas que não devem ser bloqueadas
$mls_admin_safe = [
    '/wp-admin/admin-ajax.php',
    '/wp-admin/admin-post.php',
    '/wp-admin/async-upload.php',
    '/wp-admin/load-scripts.php',
    '/wp-admin/load-styles.php',
];
if ($mls_is_admin_path && in_array($mls_path, $mls_admin_safe, true)) {
    $mls_is_admin_path = false;
}

// Se não é uma rota protegida, pula para probe shield
if (!$mls_is_login_path && !$mls_is_admin_path) {
    goto mls_probe_shield;
}

// ─── Carrega modo de login ────────────────────────────────────────────────────
$mls_login_mode = 'whitelist';
$mls_login_mode_file = $mls_uploads_dir . '/login-mode.php';
if (is_file($mls_login_mode_file) && is_readable($mls_login_mode_file)) {
    $mls_loaded_mode = @include $mls_login_mode_file;
    if (is_string($mls_loaded_mode) && in_array($mls_loaded_mode, ['whitelist', 'custom', 'standard'], true)) {
        $mls_login_mode = $mls_loaded_mode;
    }
}

// ─── Carrega whitelist de IPs ─────────────────────────────────────────────────
$mls_whitelist = ['127.0.0.1', '::1'];
$mls_whitelist_file = $mls_uploads_dir . '/whitelist-login.txt';
if (is_file($mls_whitelist_file) && is_readable($mls_whitelist_file)) {
    $mls_lines = @file($mls_whitelist_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (is_array($mls_lines)) {
        foreach ($mls_lines as $mls_line) {
            $mls_line = trim((string) $mls_line);
            if ($mls_line !== '') { $mls_whitelist[] = $mls_line; }
        }
    }
}
$mls_is_whitelisted = in_array($mls_ip, $mls_whitelist, true);

// ─── IPs whitelisted passam direto em qualquer modo ──────────────────────────
if ($mls_is_whitelisted) {
    goto mls_probe_shield;
}

// ─── Função de throttle por IP em tmpdir ─────────────────────────────────────
// Retorna true (bloqueado) quando count > limit dentro da janela.
// $suffix diferencia login de admin para contagem separada.
function mls_throttle_check($ip, $now, $window, $limit, $suffix) {
    $file = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
          . DIRECTORY_SEPARATOR . 'mls_' . $suffix . '_' . md5($ip);
    $count = 0; $ts = $now;
    if (is_file($file)) {
        $raw = @file_get_contents($file);
        if (is_string($raw) && $raw !== '') {
            $d = json_decode($raw, true);
            if (is_array($d)) {
                $count = (int) ($d['n'] ?? 0);
                $ts    = (int) ($d['t'] ?? $now);
            }
        }
    }
    if ($ts <= 0 || ($now - $ts) >= $window) { $count = 0; $ts = $now; }
    $count++;
    @file_put_contents($file, json_encode(['n' => $count, 't' => $ts]), LOCK_EX);
    return ($count > $limit);
}

// ─── Função de lockout persistente por IP em flat file ───────────────────────
// Flat file: lockouts/<md5(ip)>.php — contagem total e timestamp do lockout.
function mls_lockout_dir($uploads_dir) {
    $d = $uploads_dir . '/lockouts';
    if (!is_dir($d)) { @mkdir($d, 0755, true); }
    return $d;
}

function mls_is_locked_out($ip, $now, $uploads_dir) {
    $file = mls_lockout_dir($uploads_dir) . '/' . md5($ip) . '.php';
    if (!is_file($file) || !is_readable($file)) { return false; }
    $d = @include $file;
    if (!is_array($d)) { return false; }
    $until = (int) ($d['until'] ?? 0);
    return $until > $now;
}

function mls_set_lockout($ip, $now, $duration_seconds, $uploads_dir) {
    $file = mls_lockout_dir($uploads_dir) . '/' . md5($ip) . '.php';
    $d = ['ip' => $ip, 'until' => $now + $duration_seconds, 'ts' => $now];
    @file_put_contents($file, "<?php\nreturn " . var_export($d, true) . ";\n", LOCK_EX);
}

// ─── Carrega parâmetros de throttle do flat file ──────────────────────────────
// Padrões conservadores se o flat file não existir
$mls_throttle_window   = 300;   // 5 min
$mls_throttle_limit    = 8;     // 8 requests por janela antes de throttle
$mls_lockout_duration  = 900;   // 15 min de lockout após atingir threshold

$mls_throttle_file = $mls_uploads_dir . '/throttle-config.php';
if (is_file($mls_throttle_file) && is_readable($mls_throttle_file)) {
    $mls_tc = @include $mls_throttle_file;
    if (is_array($mls_tc)) {
        $mls_throttle_window  = max(60,  (int) ($mls_tc['window']   ?? $mls_throttle_window));
        $mls_throttle_limit   = max(3,   (int) ($mls_tc['limit']    ?? $mls_throttle_limit));
        $mls_lockout_duration = max(300, (int) ($mls_tc['lockout']  ?? $mls_lockout_duration));
    }
}

// ─── MODO: CUSTOM LOGIN URL ───────────────────────────────────────────────────
if ($mls_login_mode === 'custom') {

    // /wp-login.php: bloquear ou passar conforme cookie de bypass
    if ($mls_is_login_path) {
        $mls_original_login_behavior = '403';
        $mls_olb_file = $mls_uploads_dir . '/original-login-behavior.php';
        if (is_file($mls_olb_file) && is_readable($mls_olb_file)) {
            $mls_loaded = @include $mls_olb_file;
            if (is_string($mls_loaded) && in_array($mls_loaded, ['403', '404', 'home'], true)) {
                $mls_original_login_behavior = $mls_loaded;
            }
        }

        $mls_bypass_valid = false;
        $mls_bypass_secret = '';
        $mls_bsf = $mls_uploads_dir . '/bypass-secret.php';
        if (is_file($mls_bsf) && is_readable($mls_bsf)) {
            $mls_bs = @include $mls_bsf;
            if (is_string($mls_bs) && strlen($mls_bs) >= 32) { $mls_bypass_secret = $mls_bs; }
        }
        if ($mls_bypass_secret !== '' && isset($_COOKIE['mls_cx'])) {
            $mls_parts = explode('.', (string) $_COOKIE['mls_cx'], 2);
            if (count($mls_parts) === 2) {
                $mls_ts = (int) $mls_parts[0];
                if ($mls_ts > 0 && ($mls_now - $mls_ts) <= 1800) {
                    $mls_exp = hash_hmac('sha256', $mls_ts . '|' . $mls_ip, $mls_bypass_secret);
                    $mls_bypass_valid = function_exists('hash_equals')
                        ? hash_equals($mls_exp, $mls_parts[1])
                        : ($mls_exp === $mls_parts[1]);
                }
            }
        }

        if (!$mls_bypass_valid) {
            if ($mls_original_login_behavior === '404') {
                http_response_code(404); header('Connection: close'); exit;
            } elseif ($mls_original_login_behavior === 'home') {
                $mls_home = '/';
                $mls_hf = $mls_uploads_dir . '/site-home-url.php';
                if (is_file($mls_hf) && is_readable($mls_hf)) {
                    $mls_h = @include $mls_hf;
                    if (is_string($mls_h) && $mls_h !== '') { $mls_home = $mls_h; }
                }
                http_response_code(302); header('Location: ' . $mls_home); header('Connection: close'); exit;
            } else {
                http_response_code(403); header('Connection: close'); exit;
            }
        }
    }

    // /wp-admin/* em modo custom: proteger contra redirect-loop abuse
    // IPs autenticados têm cookie WordPress válido (não gerenciado aqui — deixa passar)
    // IPs não autenticados: throttle agressivo para cortar loop churn
    if ($mls_is_admin_path) {
        // Se tem cookie de sessão WordPress, é usuário legítimo — deixa passar
        $mls_has_wp_cookie = false;
        foreach (array_keys($_COOKIE) as $mls_ckey) {
            if (strpos((string) $mls_ckey, 'wordpress_logged_in_') === 0) {
                $mls_has_wp_cookie = true;
                break;
            }
        }
        if (!$mls_has_wp_cookie) {
            if (mls_is_locked_out($mls_ip, $mls_now, $mls_uploads_dir)) {
                http_response_code(403); header('Connection: close'); exit;
            }
            if (mls_throttle_check($mls_ip, $mls_now, $mls_throttle_window, $mls_throttle_limit, 'adm')) {
                mls_set_lockout($mls_ip, $mls_now, $mls_lockout_duration, $mls_uploads_dir);
                http_response_code(403); header('Connection: close'); exit;
            }
        }
    }

    goto mls_probe_shield;
}

// ─── MODO: STANDARD — proteção real sem whitelist obrigatória ─────────────────
if ($mls_login_mode === 'standard') {

    // /wp-login.php — throttle + lockout persistente
    if ($mls_is_login_path) {
        if (mls_is_locked_out($mls_ip, $mls_now, $mls_uploads_dir)) {
            http_response_code(403); header('Connection: close'); exit;
        }
        if (mls_throttle_check($mls_ip, $mls_now, $mls_throttle_window, $mls_throttle_limit, 'lgn')) {
            mls_set_lockout($mls_ip, $mls_now, $mls_lockout_duration, $mls_uploads_dir);
            http_response_code(403); header('Connection: close'); exit;
        }
    }

    // /wp-admin/* unauthenticated — corta redirect-loop churn
    if ($mls_is_admin_path) {
        $mls_has_wp_cookie = false;
        foreach (array_keys($_COOKIE) as $mls_ckey) {
            if (strpos((string) $mls_ckey, 'wordpress_logged_in_') === 0) {
                $mls_has_wp_cookie = true;
                break;
            }
        }
        if (!$mls_has_wp_cookie) {
            if (mls_is_locked_out($mls_ip, $mls_now, $mls_uploads_dir)) {
                http_response_code(403); header('Connection: close'); exit;
            }
            // Admin path throttle usa janela mais curta para detectar loop rápido
            if (mls_throttle_check($mls_ip, $mls_now, 60, 5, 'adm')) {
                mls_set_lockout($mls_ip, $mls_now, $mls_lockout_duration, $mls_uploads_dir);
                http_response_code(403); header('Connection: close'); exit;
            }
        }
    }

    goto mls_probe_shield;
}

// ─── MODO: WHITELIST-ONLY (padrão) ───────────────────────────────────────────
// /wp-login.php
if ($mls_is_login_path) {
    $mls_token_file      = $mls_uploads_dir . '/whitelist-login-token.php';
    $mls_temp_allow_file = $mls_uploads_dir . '/whitelist-login-temp.php';

    $mls_temp_allow = [];
    if (is_file($mls_temp_allow_file) && is_readable($mls_temp_allow_file)) {
        $mls_loaded_temp = @include $mls_temp_allow_file;
        if (is_array($mls_loaded_temp)) {
            foreach ($mls_loaded_temp as $mls_allowed_ip => $mls_expiry) {
                $mls_expiry = (int) $mls_expiry;
                if ($mls_expiry > $mls_now) { $mls_temp_allow[(string) $mls_allowed_ip] = $mls_expiry; }
            }
        }
    }

    $mls_allowed = !empty($mls_temp_allow[$mls_ip]) && (int) $mls_temp_allow[$mls_ip] > $mls_now;

    if (!$mls_allowed) {
        $mls_token_value = '';
        if (isset($_GET['mls_token']))           { $mls_token_value = trim((string) $_GET['mls_token']); }
        elseif (isset($_GET['mls_login_token'])) { $mls_token_value = trim((string) $_GET['mls_login_token']); }

        $mls_token_config = [];
        if (is_file($mls_token_file) && is_readable($mls_token_file)) {
            $mls_token_loaded = @include $mls_token_file;
            if (is_array($mls_token_loaded)) { $mls_token_config = $mls_token_loaded; }
        }

        $mls_expected_token = trim((string) ($mls_token_config['token'] ?? ''));
        $mls_duration       = max(5, (int) ($mls_token_config['duration'] ?? 60));
        $mls_token_valid    = $mls_token_value !== '' && $mls_expected_token !== '';
        if ($mls_token_valid) {
            $mls_token_valid = function_exists('hash_equals')
                ? hash_equals($mls_expected_token, $mls_token_value)
                : ($mls_expected_token === $mls_token_value);
        }
        if ($mls_token_valid) {
            $mls_temp_allow[$mls_ip] = $mls_now + ($mls_duration * 60);
            @file_put_contents($mls_temp_allow_file, "<?php\nreturn " . var_export($mls_temp_allow, true) . ";\n", LOCK_EX);
            $mls_allowed = true;
        }
    }

    if (!$mls_allowed) { http_response_code(403); header('Connection: close'); exit; }

    // Limiter secundário para IPs já permitidos
    $mls_lfile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'mls_lgn_' . md5($mls_ip);
    $mls_lcount = 0; $mls_lts = $mls_now;
    if (is_file($mls_lfile)) {
        $mls_lraw = @file_get_contents($mls_lfile);
        if (is_string($mls_lraw) && $mls_lraw !== '') {
            $mls_ld = json_decode($mls_lraw, true);
            if (is_array($mls_ld)) { $mls_lcount = (int) ($mls_ld['n'] ?? 0); $mls_lts = (int) ($mls_ld['t'] ?? $mls_now); }
        }
    }
    if ($mls_lts <= 0 || ($mls_now - $mls_lts) >= 300) { $mls_lcount = 0; $mls_lts = $mls_now; }
    $mls_lcount++;
    @file_put_contents($mls_lfile, json_encode(['n' => $mls_lcount, 't' => $mls_lts]), LOCK_EX);
    if ($mls_lcount > 5) { http_response_code(403); header('Connection: close'); exit; }
    return;
}

// /wp-admin/* em whitelist-only: bloqueia unauthenticated para cortar loop
if ($mls_is_admin_path) {
    $mls_has_wp_cookie = false;
    foreach (array_keys($_COOKIE) as $mls_ckey) {
        if (strpos((string) $mls_ckey, 'wordpress_logged_in_') === 0) {
            $mls_has_wp_cookie = true;
            break;
        }
    }
    if (!$mls_has_wp_cookie) {
        http_response_code(403); header('Connection: close'); exit;
    }
    return;
}

// ─── PROBE SHIELD ────────────────────────────────────────────────────────────
// Escopo intencional: raiz do site + /wp-content/ direto.
// NUNCA bloqueia dentro de /wp-content/plugins/, /wp-content/themes/,
// /wp-content/uploads/ — esses são arquivos legítimos de plugins e temas.
mls_probe_shield:

$mls_allowlist = [
    '/index.php', '/wp-cron.php', '/xmlrpc.php', '/wp-comments-post.php',
    '/wp-links-opml.php', '/wp-mail.php', '/wp-activate.php', '/wp-signup.php',
    '/wp-admin/admin-ajax.php', '/wp-admin/admin-post.php', '/wp-admin/async-upload.php',
    '/wp-admin/load-scripts.php', '/wp-admin/load-styles.php',
];

if (in_array($mls_path, $mls_allowlist, true)) { return; }

$mls_basename = strtolower((string) basename($mls_path));
$mls_is_php   = $mls_basename !== '' && substr($mls_basename, -4) === '.php';
if (!$mls_is_php) { return; }

// Nunca bloquear dentro de plugins, themes ou uploads — são arquivos legítimos
if (strpos($mls_path, '/wp-content/plugins/') === 0) { return; }
if (strpos($mls_path, '/wp-content/themes/')  === 0) { return; }
if (strpos($mls_path, '/wp-content/uploads/') === 0) { return; }

$mls_trimmed           = ltrim($mls_path, '/');
$mls_is_root_php       = strpos($mls_trimmed, '/') === false;
// wp-content direto = /wp-content/algo.php (sem subpasta adicional)
$mls_is_wpcontent_root = (
    strpos($mls_path, '/wp-content/') === 0 &&
    substr_count($mls_path, '/') === 2
);

// Nomes suspeitos que indicam shell/probe — só relevantes fora de plugins/themes
$mls_suspicious_names = [
    'fe5.php', 'dx.php', 'xroot.php', 'xmini.php', 'k.php', 'goods.php',
    'gettest.php', 'chosen.php', 'abcd.php', 'a5.php', '1.php', '2.php',
    '7.php', '8.php', '222.php', 'wp-update.php', 'wp.php',
    'admin.php', // legítimo dentro de plugins — já excluído acima
];

$mls_is_suspicious_name = in_array($mls_basename, $mls_suspicious_names, true);
$mls_is_numeric_php     = preg_match('/^[0-9]{1,4}\.php$/', $mls_basename) === 1;

$mls_block = false;

// Raiz do site: qualquer .php fora da allowlist é suspeito
if ($mls_is_root_php && !$mls_is_login_path) {
    $mls_block = true;
}
// /wp-content/ direto (não subpastas): bloqueia nomes suspeitos
elseif ($mls_is_wpcontent_root && ($mls_is_suspicious_name || $mls_is_numeric_php)) {
    $mls_block = true;
}

if ($mls_block) { http_response_code(403); header('Connection: close'); exit; }
