=== ML Login Secury ===
Contributors: mlopesdesign
Tags: login, security, brute force, whitelist, protection
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.2.1
License: GPLv2 or later

Professional WordPress login security with multi-mode login protection.

== Changelog ==

= 2.2.1 =
* Corrigido: erro fatal no painel (Class "ML_License_Client_V2" not found) em sites onde o ML Login Secury é o único plugin ML com licença. O arquivo da licença voltava antes de carregar o cliente. O site público e a tela de login não eram afetados.

= 2.2.0 =
* Licença pelo site tools.mlopesdesign.com.br (ML License Hub). Aceita a chave do próprio plugin ou a do Pacote Agência (todos os plugins ML em vários sites).
* Teste grátis de 30 dias por site. Quem já usava o plugin recebe o teste automaticamente na primeira visita ao painel.
* Nova aba Licença no painel: situação, plano, validade, ativar chave, teste grátis, conferir agora e remover deste site.
* Sem teste ou licença: a proteção do login e do site continua funcionando exatamente igual (bloqueio antecipado, Request Shield, limite de tentativas, XML-RPC, whitelist e token de emergência). Só fica bloqueado salvar configurações no painel. Desbloquear IPs, liberar emergência e adicionar o seu IP continuam disponíveis.
* A licença nunca é consultada na tela de login: só no painel e uma vez por dia em segundo plano.

= 2.1.2 =
* Atualizações automáticas pelo painel do WordPress, a partir das versões oficiais no GitHub (mlopesdesign/ml-login-secury-releases).
* Ícone do plugin na tela de atualizações.
* Corrigido: o carregador antecipado (mu-plugins/mls-early.php) agora só carrega o bloqueio se o arquivo do plugin existir. Antes, uma atualização ou a remoção do plugin derrubava o site inteiro com erro fatal.
* Corrigido: ao desativar o plugin, o bloqueio antecipado é removido (antes continuava ativo mesmo com o plugin desligado).

= 2.1.0 =
* Fixed: standard mode was effectively open — replaced tmpdir-only counter with persistent flat-file lockout per IP.
* Fixed: unauthenticated /wp-admin/* requests had no protection in any non-whitelist mode — added early throttle + lockout in early-block.php covering all modes.
* Fixed: redirect-loop churn (wp-admin → wp-login → wp-admin) now terminated at MU layer before WordPress executes.
* Added: throttle-config.php flat file export (window, limit, lockout duration — configurable in admin).
* Added: lockouts/ directory under ml-login-secury uploads for persistent per-IP lockout state.
* Improved: wp-admin protection checks for wordpress_logged_in_* cookie before blocking — authenticated users never affected.
* UI: login_mode tab updated with throttle config fields and corrected descriptions.
* Backward compatible: default remains whitelist mode, all existing settings preserved.

= 2.0.4 =
* Fixed redirect_to injection to prevent redirect to home after login.

= 2.0.3 =
* Architecture: custom slug in plugin layer, early-block only blocks wp-login.php.

== Upgrade Notice ==

= 2.1.2 =
Ativação das atualizações automáticas. Sites com versão anterior precisam instalar esta versão uma vez (enviar o ZIP em Plugins > Adicionar novo > Enviar plugin, opção Substituir a atual).

